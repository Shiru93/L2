/*
 * Ziya EMRE 12212738
 * Je déclare qu'il s'agit de mon propre travail
 * Ce travail a été réalisé intégralement par un être humain
 */

#include <unistd.h>
#include <sys/socket.h>
#include <fcntl.h>
#include <pthread.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "list/list.h"
#include "user.h"

#define PORT_FREESCORD 4321
#define LISTEN_BACKLOG SOMAXCONN

#define handle_error(msg) \
	do { perror(msg); exit(EXIT_FAILURE); } while(0);

/*
 * Variables globales (accessible par tous les threads)
 */
int pipe_fd[2];
struct list * users;

/** Gérer toutes les communications avec le client renseigné dans
 * user, qui doit être l'adresse d'une struct user */
void *handle_client(void *user);

/** Créer et configurer une socket d'écoute sur le port donné en argument
 * retourne le descripteur de cette socket, ou -1 en cas d'erreur */
int create_listening_sock(uint16_t port);

void *repeteur(void * arg);

int main(int argc, char *argv[])
{
	// struct sockaddr_in peer_addr;
	// socklen_t peer_addr_size = sizeof(peer_addr);
	int sfd = create_listening_sock(PORT_FREESCORD);
	pthread_t tid;
	// char buf[4096];
	// ssize_t n;
	users = list_create();

	if(pipe(pipe_fd) == -1)
		handle_error("pipe");

	pthread_t rep_tid;
	pthread_create(&rep_tid, NULL, repeteur, NULL);
	pthread_detach(rep_tid);

	while(1){
		// int cfd = accept(sfd, (struct sockaddr *) &peer_addr, &peer_addr_size);
		// if(cfd == -1)
		// 	handle_error("accept");

		struct user *u = user_accept(sfd);

		// Quand read return 0, le client s'est déconnecté -> on sort de la boucle
		// while((n = read(cfd, buf, sizeof(buf))) > 0)
		// 	write(cfd, buf, n); 	// On renvoie exactement ce qu'on a lu

		// close(cfd);

		// Ici on va créer un thread pour gérer cfd
		pthread_create(&tid, NULL, handle_client, (void *) u);
		pthread_detach(tid);
	}

	return 0;
}

void *handle_client(void *clt)
{
	struct user *u = (struct user *) clt;
	char buf[4096];
	ssize_t n;

	list_add(users, u);

	while((n = read(u->sock, buf, sizeof(buf))) > 0)
		write(pipe_fd[1], buf, n);

	list_remove_element(users, u);
	user_free(u);
	close(u->sock);

	return NULL;
}

int create_listening_sock(uint16_t port)
{
	int sfd;
	struct sockaddr_in my_addr;

	sfd = socket(AF_INET, SOCK_STREAM, 0);
	if(sfd == -1)
		handle_error("socket");

	my_addr.sin_family = AF_INET;
	
	/*
	 * Les processeurs stockent les nombres dans un certain ordre d'octets (little-endian sur x86). 
	 * Mais le réseau utilise un ordre différent (big-endian). Il faut convertir :
	 */
	my_addr.sin_port = htons(port);

	/*
	 * INADDR_ANY signifie "accepte les connexions sur toutes les interfaces réseau de la machine" (localhost, WiFi, ethernet...). 
	 * C'est ce qu'on veut pour un serveur.
	 */
	my_addr.sin_addr.s_addr = INADDR_ANY; 	// Adresse internet dans l'ordre des octets réseaux 

	/*
	 * Le cast (struct sockaddr *) est nécessaire car bind est générique — elle accepte plusieurs types d'adresses
	 */
	if(bind(sfd, (struct sockaddr *) &my_addr, sizeof(my_addr)) == -1)
		handle_error("bind");

	if(listen(sfd, LISTEN_BACKLOG) == -1)
		handle_error("listen");

	return sfd;
}

void *repeteur(void * arg){
	char buf[4096];

	while(1){
		ssize_t n = read(pipe_fd[0], buf, sizeof(buf));

		struct node * curr = users->first;
		for(; curr != NULL; curr = curr->next){
			struct user * u = (struct user *) curr->elt;
			write(u->sock, buf, n);
		}
	}

	return NULL;
}