/**
 * 
 */
package poo2.util.stream;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 * 
 */
public abstract class AbstractStream<E> implements SimpleStream<E> {
	private boolean isClosed;
	
	public AbstractStream() {
	}

	@Override
	public SimpleStream<E> filter(Predicate<? super E> p) {
		if (isClosed()) {
			throw new IllegalStateException();
		}
		return new StreamFilter<E>(this, p);
	}
	
	@Override
	public <T> SimpleStream<T> map(Function<? super E, ? extends T> mapper) {
		if (isClosed()) {
			throw new IllegalStateException();
		}
		return new StreamMap<>(this, mapper);
	}

	@Override
	public SimpleStream<E> concat(SimpleStream <? extends E> other) {
		if (isClosed()) {
			throw new IllegalStateException();
		}
		return new StreamConcat<>(this, other);
	}
	
	@Override
	public SimpleStream<E> takeWhile(Predicate<? super E> p) {
		if (isClosed()) {
			throw new IllegalStateException();
		}
		return new StreamTakeWhile<>(this, p);

	}
	@Override
	public List<E> toList() {
		if (isClosed()) {
			throw new IllegalStateException();
		}
		Iterator<E> theIterator = iterator();
		List<E> result = new LinkedList<E>();
		while (theIterator.hasNext()) {
			result.add(theIterator.next());
		}
		return result;
	}

	@Override
	public Set<E> toSet() {
		if (isClosed()) {
			throw new IllegalStateException();
		}
		Iterator<E> theIterator = iterator();
		Set<E> result = new HashSet<E>();
		while (theIterator.hasNext()) {
			result.add(theIterator.next());
		}
		return result;
	}
	
	@Override
	public abstract Iterator<E> iterator();

	public boolean isClosed() {
		return isClosed;
	}

	public void close() {
		isClosed = true;
	}
}
