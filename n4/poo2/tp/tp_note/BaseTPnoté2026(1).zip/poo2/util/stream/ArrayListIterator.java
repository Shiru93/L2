/**
 * 
 */
package poo2.util.stream;

import java.util.ListIterator;
import java.util.NoSuchElementException;

/**
 * Un ListIterator pour les tableaux. 
 */
public class ArrayListIterator<E> implements ListIterator<E> {
	private E[] tab;
	private int nextIndex;
	private int previousIndex;
	private int lastIndex;

	/**
	 * 
	 */
	public ArrayListIterator(E[] tab) {
		if (tab == null) {
			throw new NullPointerException();
		}
		this.tab = tab;
		previousIndex = -1;
		lastIndex = -1;
	}

	public ArrayListIterator(E[] tab, int index) {
		if (tab == null) {
			throw new NullPointerException();
		}
		if (index < 0 || index > tab.length) {
			throw new IndexOutOfBoundsException();
		}
		this.tab = tab;
		nextIndex = index;
		previousIndex = index - 1;
		lastIndex = -1;
	}

	@Override
	public boolean hasNext() {
		return nextIndex < tab.length;
	}

	@Override
	public E next() {
		if (!hasNext()) {
			throw new NoSuchElementException();
		}
		lastIndex = nextIndex;
		nextIndex++;
		previousIndex++;
		return tab[lastIndex];
	}

	@Override
	public void add(E elt) {
		throw new UnsupportedOperationException();
	}

	@Override
	public boolean hasPrevious() {
		return this.previousIndex >= 0;
	}

	@Override
	public int nextIndex() {
		if (!hasNext()) {
			return tab.length;
		}
		return nextIndex;
	}

	@Override
	public E previous() {
		if (!hasPrevious()) {
			throw new NoSuchElementException();
		}
		lastIndex = previousIndex;
		previousIndex--;
		nextIndex--;
		return tab[lastIndex];
	}

	@Override
	public int previousIndex() {
		if (!hasPrevious()) {
			return -1;
		}
		return previousIndex;
	}

	@Override
	public void remove() {
		throw new UnsupportedOperationException();
	}

	@Override
	public void set(E elt) {
		if (lastIndex == -1) {
			throw new IllegalStateException();
		}
		tab[lastIndex] = elt;
	}

}
