/**
 * 
 */
package poo2.util.stream;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.function.Predicate;

/**
 * 
 */
public class TakeWhileIterator<E> implements Iterator<E> {
	private Iterator<? extends E> iter;
	private Predicate<? super E> pred;
	private boolean nextFound;
	private E nextItem;

	/**
	 * 
	 */
	public TakeWhileIterator(Iterator<? extends E> iter, Predicate<? super E> p) {
		if (iter == null || p == null) {
			throw new NullPointerException();
		}
		this.iter = iter;
		pred = p;
		nextFound = false;
		if (iter.hasNext()) {
			nextItem = iter.next();
			nextFound = pred.test(nextItem);
		}
	}

	@Override
	public boolean hasNext() {
		return nextFound;
	}

	@Override
	public E next() {
		if (!hasNext()) {
			throw new NoSuchElementException();
		}
		E result = nextItem;
		nextFound = false;
		if (iter.hasNext()) {
			nextItem = iter.next();
			nextFound = pred.test(nextItem);
		}
		return result;
	}

}
