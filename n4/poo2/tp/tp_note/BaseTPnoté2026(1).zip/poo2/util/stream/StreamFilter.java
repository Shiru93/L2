/**
 * 
 */
package poo2.util.stream;

import java.util.Iterator;
import java.util.function.Predicate;

/**
 * 
 */
class StreamFilter<E> extends AbstractStream<E> {
	private SimpleStream<? extends E> theStream;
	private Predicate<? super E> pred;
	
	StreamFilter(SimpleStream<? extends E> s, Predicate<? super E> p) {
		theStream = s;
		pred = p;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public Iterator<E> iterator() {
		if (isClosed()) {
			throw new IllegalStateException();
		}
		Iterator<E> theIterator = (Iterator<E>) theStream.iterator();
		close();
		return new FilterIterator<>(theIterator, pred);
	}

}
