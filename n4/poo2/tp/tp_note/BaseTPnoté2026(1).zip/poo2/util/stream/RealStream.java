/**
 * 
 */
package poo2.util.stream;

import java.util.Iterator;

/**
 * 
 */
public class RealStream<E> extends AbstractStream<E> {
	private Iterator<? extends E> theIterator;
	
	public RealStream(Iterator<? extends E> iter) {
		theIterator = iter;
	}
	
	public RealStream(Iterable<? extends E> c) {
		theIterator = c.iterator();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public Iterator<E> iterator() {
		if (isClosed()) {
			throw new IllegalStateException();
		}
		close();
		return (Iterator<E>) theIterator;
	}

}
