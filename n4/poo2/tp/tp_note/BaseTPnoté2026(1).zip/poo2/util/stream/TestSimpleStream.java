package poo2.util.stream;

import static poo2.zork.model.ObjetZork.*;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import poo2.util.EnumCollection;
import poo2.zork.model.ObjetZork;

public class TestSimpleStream {

	public static void main(String[] args) {
		EnumCollection<ObjetZork> c = new EnumCollection<>(ObjetZork.class, List.of(CHAISE, TABLE, CHAISE, PIZZA, CLEF, LAMPE, TRESOR, PIZZA, ORDINATEUR, TRESOR));
		System.out.println("Sans filtre: " + c);
		System.out.println("Avec filtre (oz != CHAISE): ");
		Iterator<ObjetZork> iter = new FilterIterator<>(c.iterator(), (oz) -> oz != CHAISE);
		while (iter.hasNext()) {
			System.out.print(iter.next() + ":");
		}
		System.out.println("\nAjout du filtre oz.isTransportable()");
		iter = new FilterIterator<>(c.iterator(), (oz) -> oz != CHAISE);
		iter = new FilterIterator<>(iter, (oz) -> oz.isTransportable());
		while (iter.hasNext()) {
			System.out.print(iter.next() + ":");
		}
		
		System.out.println("\nAvec le filtre oz != PIZZA && oz.isTransportable() && oz.getWeight() >= 10:");
		iter = c.simpleStream()
				.filter((oz) -> oz != PIZZA)
				.filter((oz) -> oz.isTransportable())
				.filter((oz) -> oz.getWeight() >= 10)
				.iterator();
		while (iter.hasNext()) {
			System.out.print(iter.next() + ":");
		}
		System.out.println("\nAvec le filtre oz != PIZZA, map to niceName et production d'un Set:");
		Set<String> names = c.simpleStream()
				.filter((oz) -> oz != PIZZA)
				.map((oz) -> oz.getNiceName())
				.toSet();
		System.out.println(names);
		System.out.println("\nTest fermeture:");
		SimpleStream<ObjetZork> s0 = c.simpleStream();
		SimpleStream<ObjetZork> s1 = s0.filter((oz) -> oz != PIZZA);
		SimpleStream<ObjetZork> s2 = s1.filter((oz) -> oz.isTransportable());
		SimpleStream<ObjetZork> s3 = s2.filter((oz) -> oz.getWeight() >= 10);
		SimpleStream<String> s4 = s3.map((oz) -> oz.getNiceName());
		names = s4.toSet();
		System.out.println(names);
		s4.iterator(); // Déclenche une IllegalStateException
		System.out.println("\nC'est fini");
	}

}
