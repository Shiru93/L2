/**
 * 
 */
package poo2.util.stream;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.function.Predicate;

/**
 * 
 */
public class FilterIterator<E> implements Iterator<E> {
	private Iterator<? extends E> supportIter;
	private Predicate<? super E> predicate;
	private E nextItem;
	private boolean nextFound;

	/**
	 * 
	 */
	public FilterIterator(Iterator<? extends E> iter, Predicate<? super E> p) {
		this.supportIter = iter;
		this.predicate = p;
		findNext();
	}

	private void findNext() {
		nextFound = false;
		while (!nextFound && supportIter.hasNext()) {
			nextItem = supportIter.next();
			nextFound = predicate.test(nextItem);
		}
	}

	@Override
	public boolean hasNext() {
		return nextFound;
	}

	@Override
	public E next() {
		if (!hasNext()) {
			throw new NoSuchElementException();
		}
		E lastItem = nextItem;
		findNext();
		return lastItem;
	}

	@Override
	public final void remove() {
		throw new UnsupportedOperationException();
	}

}
