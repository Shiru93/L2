/**
 * 
 */
package poo2.util.stream;

import java.util.Iterator;

/**
 * 
 */
class StreamConcat<E> extends AbstractStream<E> {
	private SimpleStream<? extends E> s1;
	private SimpleStream<? extends E> s2;
	
	StreamConcat(SimpleStream<? extends E> s1, SimpleStream<? extends E> s2) {
		this.s1 = s1;
		this.s2 = s2;
	}
	
	@Override
	public Iterator<E> iterator() {
		if (isClosed()) {
			throw new IllegalStateException();
		}
		@SuppressWarnings("unchecked")
		Iterator<E> iter1 = (Iterator<E>) s1.iterator();
		@SuppressWarnings("unchecked")
		Iterator<E> iter2 = (Iterator<E>) s2.iterator();
		close();
		return new ConcatIterator<>(iter1, iter2);
	}

}
