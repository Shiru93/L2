package poo2.util.stream;

import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.function.Function;

public class MappingIterator<R, E> implements Iterator<E> {
	private Iterator<? extends R> supportIter;
	private Function<? super R, ? extends E> func;

	public MappingIterator(Iterator<? extends R> iter, Function<? super R, ? extends E> mapper) {
		supportIter = iter;
		func = mapper;
	}

	@Override
	public boolean hasNext() {
		return supportIter.hasNext();
	}

	@Override
	public E next() {
		if (!supportIter.hasNext()) {
			throw new NoSuchElementException();
		}
		return func.apply(supportIter.next());
	}

	@Override
	public final void remove() {
		throw new UnsupportedOperationException();
	}
}
