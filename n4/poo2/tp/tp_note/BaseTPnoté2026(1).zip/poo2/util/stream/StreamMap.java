/**
 * 
 */
package poo2.util.stream;

import java.util.Iterator;
import java.util.function.Function;

/**
 * 
 */
class StreamMap<R, E> extends AbstractStream<E> {
	private SimpleStream<? extends R> theStream;
	private Function<? super R, ? extends E> pred;
	
	StreamMap(SimpleStream<? extends R> s, Function<? super R, ? extends E> p) {
		theStream = s;
		pred = p;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public Iterator<E> iterator() {
		if (isClosed()) {
			throw new IllegalStateException();
		}
		Iterator<R> theIterator = (Iterator<R>) theStream.iterator();
		close();
		return new MappingIterator<>(theIterator, pred);
	}

}
