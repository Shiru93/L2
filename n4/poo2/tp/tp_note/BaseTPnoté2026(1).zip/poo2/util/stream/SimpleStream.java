/**
 * 
 */
package poo2.util.stream;

import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 * 
 */
public interface SimpleStream<E> {
	/**
	 * Renvoie un itérateur sur les éléments de ce SimpleStream. Cet itérateur ne
	 * supporte pas l'opération remove et déclenchera une exception
	 * UnsupportedException en cas d'appel de cette méthode.
	 * 
	 * @return un itérateur sur les éléments de ce SimpleStream.
	 * 
	 * @ensures \result != null;
	 * 
	 * @pure
	 */
	Iterator<E> iterator();

	SimpleStream<E> filter(Predicate<? super E> p);

	<R> SimpleStream<R> map(Function<? super E, ? extends R> mapper);
	
	SimpleStream<E> concat(SimpleStream<? extends E> other);
	
	SimpleStream<E> takeWhile(Predicate<? super E> p);

	List<E> toList();

	Set<E> toSet();

	boolean isClosed();

	void close();

}
