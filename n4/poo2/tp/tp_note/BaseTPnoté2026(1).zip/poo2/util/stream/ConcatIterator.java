/**
 * 
 */
package poo2.util.stream;

import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

/**
 * 
 */
public class ConcatIterator<E> implements Iterator<E> {
	private Iterator<? extends E> iter1;
	private Iterator<? extends E> iter2;

	/**
	 * 
	 */
	public ConcatIterator(Iterator<? extends E> it1, Iterator<? extends E> it2) {
		if (it1 == null || it2 == null) {
			throw new NullPointerException();
		}
		this.iter1 = it1;
		this.iter2 = it2;
	}

	@Override
	public boolean hasNext() {
		return iter1.hasNext() || iter2.hasNext();
	}

	@Override
	public E next() {
		if (!hasNext()) {
			throw new NoSuchElementException();
		}
		if (iter1.hasNext()) {
			return iter1.next();
		}
		return iter2.next();
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		List<String> l1 = List.of("a", "b","c"),
				l2 = List.of("D","E","F");
		Iterator<String> iter = new ConcatIterator<>(l1.iterator(), l2.iterator());
		while (iter.hasNext()) {
			System.out.print(":" + iter.next());
		}
		System.out.println();
		// Affiche: :a:b:c:D:E:F
	}
}
