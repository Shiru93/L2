/**
 * 
 */
package poo2.util.stream;

import java.util.Iterator;
import java.util.function.Predicate;

/**
 * 
 */
class StreamTakeWhile<E> extends AbstractStream<E> {
	private SimpleStream<? extends E> theStream;
	private Predicate<? super E> pred;

	StreamTakeWhile(SimpleStream<? extends E> s, Predicate<? super E> p) {
		this.theStream = s;
		this.pred = p;
	}

	@Override
	public Iterator<E> iterator() {
		if (isClosed()) {
			throw new IllegalStateException();
		}
		@SuppressWarnings("unchecked")
		Iterator<E> iter = (Iterator<E>) theStream.iterator();
		close();
		return new TakeWhileIterator<>(iter, pred);
	}

}
