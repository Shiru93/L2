package poo2.util;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * Itérateur pour la classe EnumCollection.
 * 
 * @param E le type enum des éléments
 * 
 * @author Marc Champesme
 * @version 24/11/2025
 */
public class EnumCollectionIterator<E extends Enum<E>> implements Iterator<E> {
	private E[] allValues;
	private int[] content;
	private int nextIndex;
	private int lastIndex;
	private boolean removeAllowed;
	private int nbOcc;

	/**
	 * Initialise un nouvel itérateur pour l'EnumCollection spécifiée.
	 * 
	 * @param c       la collection sur laquelle opère cet itérateur
	 * @param values  tableau contenant toutes les instances du type enum
	 * @param content tableau contenant le nombre d'occurences de chaque instance du
	 *                type enum dans la collection spécifiée ainsi que le nombre
	 *                d'éléments de la collection
	 * 
	 * @requires c != null && values != null && content != null;
	 * @requires content.length == values.length;
	 * @requires (\forall E elt; c.contains(elt); content[elt.ordinal()] ==
	 *           c.frequencyOf(elt));
	 * @requires (\forall int i; i >= 0 && i < content.length; content[i] ==
	 *           c.frequencyOf(values[i]));
	 * @ensures hasNext() <==> !c.isEmpty();
	 * 
	 * @throws NullPointerException     si un des paramètres est null
	 * @throws IllegalArgumentException si les paramètres ne respectent pas une
	 *                                  autre pré-condition
	 */
	public EnumCollectionIterator(EnumCollection<E> c, E[] values, int[] content) {
		if (c == null || values == null || content == null) {
			throw new NullPointerException();
		}
		if (content.length != values.length) {
			throw new IllegalArgumentException();
		}
		this.allValues = values;
		this.content = content;
		nextIndex = 0;
		while (nextIndex < content.length && content[nextIndex] == 0) {
			nextIndex++;
		}
		if (nextIndex < content.length) {
			nbOcc = content[nextIndex];
		}
	}

	/**
	 * @pure
	 */
	@Override
	public boolean hasNext() {
		return nextIndex < content.length;
	}

	@Override
	public E next() {
		if (nextIndex == allValues.length) {
			throw new NoSuchElementException();
		}
		E elt = allValues[nextIndex];
		lastIndex = nextIndex;
		nbOcc--;
		if (nbOcc == 0) {
			nextIndex++;
			while (nextIndex < content.length && content[nextIndex] == 0) {
				nextIndex++;
			}
			if (nextIndex < content.length) {
				nbOcc = content[nextIndex];
			}
		}
		removeAllowed = true;
		return elt;
	}

	/**
	 * Retire de la collection le dernier élément renvoyé par next(). Cette méthode
	 * ne peut être appelée qu'une fois pour chaque appel à next().
	 * 
	 * @throws IllegalStateException si la méthode next() n'a pas encore été appelée
	 *                               ou bien que la méthode remove() a déjà été
	 *                               appelée depuis le dernier appel à next().
	 */
	@Override
	public void remove() {
		if (!removeAllowed) {
			throw new IllegalStateException();
		}
		content[lastIndex]--;
		removeAllowed = false;
	}

}
