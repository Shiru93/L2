/**
 * 
 */
package poo2.zork.controller;

import static poo2.zork.view.SelectionMode.NO_SELECTION;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import poo2.zork.model.ObjetZork;
import poo2.zork.model.room.Room;
import poo2.zork.view.ListView;


/**
 * Commande permettant d'afficher les objets présents dans la pièce courante.
 * Cette classe implémente les interfaces {@link Command} et {@link ActionListener}
 * pour gérer l'affichage de l'inventaire de la pièce et les interactions utilisateur.
 *
 * @author Marc Champesme
 * @version 18 avril 2026
 */
public class RoomInventoryCommand implements Command, ActionListener {

    /** Référence vers le jeu en cours. */
    private Game theGame;

    /**
     * Construit une nouvelle commande pour afficher l'inventaire de la pièce courante.
     *
     * @param theGame le jeu pour lequel cette commande est créée
     * @throws NullPointerException si le jeu est {@code null}
     */
    public RoomInventoryCommand(Game theGame) {
        if (theGame == null) {
            throw new NullPointerException("Le jeu ne peut pas être null.");
        }
        this.theGame = theGame;
    }

    /**
     * Retourne une description de l'aide pour cette commande.
     * Explique ce que fait la commande lorsqu'elle est exécutée.
     *
     * @return une chaîne de caractères décrivant l'aide de la commande
     */
    @Override
    public String getHelp() {
        return "Affiche les objets présents dans la pièce courante";
    }

    /**
     * Exécute la commande pour afficher l'inventaire de la pièce courante.
     * Crée une vue graphique affichant la liste des objets présents dans la pièce,
     * ainsi que le nombre total d'objets. Si la pièce ne contient aucun objet,
     * un message d'alerte est affiché.
     *
     * @throws NullPointerException si la pièce courante est {@code null}
     */
    @Override
    public void execute() {
        Room currentRoom = theGame.getCurrentRoom();
        if (currentRoom == null) {
            throw new NullPointerException("La pièce courante ne peut pas être null.");
        }

        ListView<ObjetZork> objMenu = ListView.builder(currentRoom)
        							.withGUI(theGame.getFrame(), this)
        							.withSelectionMode(NO_SELECTION)
                                    .withTitle("Inventaire de la pièce")
                                    .withHeaderText("Voici les objets présents dans la pièce courante:")
                                    .withFooterText("La pièce contient " + currentRoom.size() + " objet(s)")
                                    .build();

        if (currentRoom.isEmpty()) {
            objMenu.showAlertMsg("Il n'y a aucun objet dans cette pièce");
        } else {
            objMenu.showView();
        }
    }

    /**
     * Réaffiche le menu principal du jeu après consultation de l'inventaire de la pièce.
     *
     * @param e l'événement d'action
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        theGame.showMenu();
    }

    /**
     * Retourne une représentation textuelle de cette commande.
     *
     * @return une chaîne de caractères décrivant cette commande
     */
    @Override
    public String toString() {
        return "Inventaire de la pièce courante";
    }
}
