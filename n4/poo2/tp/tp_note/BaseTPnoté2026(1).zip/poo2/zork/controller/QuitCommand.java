/**
 * 
 */
package poo2.zork.controller;

import javax.swing.JOptionPane;


/**
 * Commande permettant de quitter définitivement le jeu.
 * Cette classe implémente l'interface {@link Command} pour fournir
 * une commande de sortie propre du jeu.
 *
 * @author Marc Champesme
 * @version 18 avril 2026
 */
public class QuitCommand implements Command {

    /** Référence vers le jeu en cours. */
    private Game theGame;

    /**
     * Construit une nouvelle commande pour quitter le jeu.
     *
     * @param theGame le jeu pour lequel cette commande est créée
     * @throws NullPointerException si le jeu est {@code null}
     */
    public QuitCommand(Game theGame) {
        if (theGame == null) {
            throw new NullPointerException("Le jeu ne peut pas être null.");
        }
        this.theGame = theGame;
    }

    /**
     * Retourne un texte d'aide pour cette commande.
     * Explique que cette commande permet de quitter le jeu définitivement.
     *
     * @return une chaîne de caractères décrivant l'aide de la commande
     */
    @Override
    public String getHelp() {
        return "Pour quitter le jeu définitivement";
    }

    /**
     * Exécute la commande pour quitter le jeu.
     * Affiche un message d'au revoir et quitte l'application.
     *
     * @throws NullPointerException si la fenêtre du jeu est {@code null}
     */
    @Override
    public void execute() {
        JOptionPane.showMessageDialog(theGame.getFrame(), "Au revoir!");
        System.exit(0);
    }

    /**
     * Retourne une représentation textuelle de cette commande.
     * Cette méthode fournit une description concise de la commande.
     *
     * @return une chaîne de caractères décrivant cette commande
     */
    @Override
    public String toString() {
        return "Quitter";
    }
}
