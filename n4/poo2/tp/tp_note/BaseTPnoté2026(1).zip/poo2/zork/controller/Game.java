/**
 * 
 */
package poo2.zork.controller;

import static poo2.zork.model.ObjetZork.TRESOR;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Optional;

import javax.swing.JFrame;

import poo2.zork.model.Gamer;
import poo2.zork.model.Location;
import poo2.zork.model.map.GameMap;
import poo2.zork.model.map.RandomMapBuilder;
import poo2.zork.model.room.Room;
import static poo2.zork.view.SelectionMode.*;
import poo2.zork.view.ListView;

/**
 * Classe principale représentant un jeu d'aventure textuel.
 * Gère la carte du jeu, le joueur, l'emplacement actuel,
 * ainsi que l'interface graphique principale du menu des commandes.
 * Elle implémente {@link ActionListener} pour réagir aux actions de l'utilisateur.
 *
 * @author Marc Champesme
 * @version 18 avril 2026
 */
public class Game implements ActionListener {

    /** Carte du jeu contenant les différentes pièces et leurs connexions. */
    private GameMap map;

    /** Joueur actuel du jeu. */
    private Gamer theGamer;

    /** Emplacement actuel du joueur sur la carte. */
    private Location currentLocation;

    /** Menu principal du jeu affichant les commandes disponibles. */
    private ListView<Command> mainMenu;

    /** Fenêtre principale de l'interface graphique. */
    private JFrame theFrame;

    /**
     * Construit une nouvelle instance du jeu avec une fenêtre principale.
     * Initialise la carte du jeu, le joueur, et le menu principal des commandes.
     *
     * @param frame la fenêtre principale de l'interface graphique
     * @throws NullPointerException si la fenêtre est {@code null}
     */
    public Game(JFrame frame) {
        if (frame == null) {
            throw new NullPointerException("La fenêtre principale ne peut pas être null.");
        }
        theFrame = frame;
        map = new RandomMapBuilder()
                .withColNb(10)
                .withLineNb(10)
                .withRoomNb(40)
                .withNcopiesOfRoom("Amphi", "Description de l'amphi", 5)
                .withNcopiesOfRoom("Salle TD", "Description de la salle TD", 10)
                .withNcopiesOfRoom("Salle TP", "Description de la salle TP", 10)
                .withNcopiesOfRoom("Autre salle", "Description de la salle", 10)
                .build();
        theGamer = new Gamer("Jeanne", "The better gameuse of the universe");
        currentLocation = map.getEntranceLocation();
        Optional<Room> currentRoom = map.get(currentLocation);
        List<Command> lCmd = List.of(new GoCommand(this), new TakeObjectCommand(this),
                            new DropObjectCommand(this),
                            new GamerInventoryCommand(this), new RoomInventoryCommand(this),
                            new QuitCommand(this));
        mainMenu = ListView.builder(lCmd)
        		.withGUI(theFrame, this)
        		.withSelectionMode(SINGLE_SELECTION)
                .withTitle("Menu principal")
                .withHeaderText(theGamer.getLongDescriotion() + " est dans la pièce:\n"
                            + currentRoom.get().getLongDescriotion())
                .withFooterText("Pour gagner vous devez trouver le trésor.")
                .build();
    }

    /**
     * Retourne la fenêtre principale du jeu.
     *
     * @return la fenêtre principale
     */
    public JFrame getFrame() {
        return theFrame;
    }

    /**
     * Retourne le joueur actuel du jeu.
     *
     * @return le joueur actuel
     */
    public Gamer getGamer() {
        return theGamer;
    }

    /**
     * Retourne la carte du jeu.
     *
     * @return la carte du jeu
     */
    public GameMap getMap() {
        return map;
    }

    /**
     * Retourne l'emplacement actuel du joueur sur la carte.
     *
     * @return l'emplacement actuel
     */
    public Location getCurrentLocation() {
        return this.currentLocation;
    }

    /**
     * Définit l'emplacement actuel du joueur sur la carte.
     *
     * @param loc le nouvel emplacement
     * @throws NullPointerException si l'emplacement est {@code null}
     */
    public void setCurrentLocation(Location loc) {
        if (loc == null) {
            throw new NullPointerException("L'emplacement ne peut pas être null.");
        }
        this.currentLocation = loc;
    }

    /**
     * Retourne la pièce actuelle où se trouve le joueur.
     *
     * @return la pièce actuelle
     * @throws NoSuchElementException si aucune pièce n'est présente à l'emplacement actuel
     */
    public Room getCurrentRoom() {
        return map.get(currentLocation).get();
    }

    /**
     * Affiche le menu principal du jeu.
     * Vérifie si le joueur a gagné et affiche un message de félicitations si c'est le cas.
     * Affiche une erreur si aucune pièce n'est présente à l'emplacement actuel.
     */
    public void showMenu() {
        if (theGamer.contains(TRESOR)) {
            mainMenu.showNotificationMsg("Félicitations!\nVOUS AVEZ GAGNÉ!!!");
            System.exit(0);
        }
        Optional<Room> currentRoom = map.get(currentLocation);
        if (currentRoom.isEmpty()) {
            mainMenu.showErrorMsg("Erreur: aucune pièce présente dans le jeu!!");
            System.exit(0);
        }
        mainMenu.showView();
    }

    /**
     * Méthode appelée lorsqu'une action est effectuée par l'utilisateur.
     * Récupère la commande sélectionnée et l'exécute.
     *
     * @param e l'événement d'action
     * @throws NullPointerException si aucune commande n'est sélectionnée
     */
    public void actionPerformed(ActionEvent e) {
        Command cmd = mainMenu.getSelectedValue();
        if (cmd == null) {
            throw new NullPointerException("Aucune commande sélectionnée.");
        }
        cmd.execute();
    }
}
