/**
 * 
 */
package poo2.zork.controller;

import static poo2.zork.view.SelectionMode.NO_SELECTION;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import poo2.zork.model.ObjetZork;
import poo2.zork.view.ListView;


/**
 * Commande permettant d'afficher les objets portés par le joueur.
 * Cette classe implémente les interfaces {@link Command} et {@link ActionListener}
 * pour gérer l'affichage de l'inventaire et les interactions utilisateur.
 *
 *
 * @author Marc Champesme
 * @version 18 avril 2026
 */
public class GamerInventoryCommand implements Command, ActionListener {

    /** Référence vers le jeu en cours. */
    private Game theGame;

    /**
     * Construit une nouvelle commande pour afficher l'inventaire du joueur.
     *
     * @param theGame le jeu pour lequel cette commande est créée
     * @throws NullPointerException si le jeu est {@code null}
     */
    public GamerInventoryCommand(Game theGame) {
        if (theGame == null) {
            throw new NullPointerException("Le jeu ne peut pas être null.");
        }
        this.theGame = theGame;
    }

    /**
     * Retourne une description de l'aide pour cette commande.
     * Explique ce que fait la commande lorsqu'elle est exécutée.
     *
     * @return une chaîne de caractères décrivant l'aide de la commande
     */
    @Override
    public String getHelp() {
        return "Affiche les objets portés par le joueur";
    }

    /**
     * Exécute la commande pour afficher l'inventaire du joueur.
     * Crée une vue graphique affichant la liste des objets portés par le joueur,
     * ainsi que le poids total de ces objets. Si le joueur ne possède aucun objet,
     * un message d'alerte est affiché.
     *
     */
    @Override
    public void execute() {
        ListView<ObjetZork> objMenu = ListView.builder(theGame.getGamer())
        								.withGUI(theGame.getFrame(), this)
        								.withSelectionMode(NO_SELECTION)
                                        .withTitle("Inventaire du joueur")
                                        .withHeaderText("Voici les objets transportés par le joueur:")
                                        .withFooterText("Le poids total des objets transportés est: "
                                        + theGame.getGamer().getWeight())
                                        .build();
        if (theGame.getGamer().isEmpty()) {
            objMenu.showAlertMsg("Le joueur ne possède aucun objet");
        } else {
            objMenu.showView();
        }
    }

    /**
     * Méthode appelée lorsqu'une action est effectuée par l'utilisateur.
     * Réaffiche le menu principal du jeu après consultation de l'inventaire.
     *
     * @param e l'événement d'action
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        theGame.showMenu();
    }

    /**
     * Retourne une représentation textuelle de cette commande.
     * Cette méthode fournit une description concise de la commande.
     *
     * @return une chaîne de caractères décrivant cette commande
     */
    @Override
    public String toString() {
        return "Inventaire du joueur";
    }
}
