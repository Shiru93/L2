/**
 * 
 */
package poo2.zork.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.EnumMap;

import javax.swing.JFrame;

import poo2.zork.model.Direction;
import poo2.zork.model.Location;
import poo2.zork.model.map.GameMap;
import poo2.zork.view.ListView;
import static poo2.zork.view.SelectionMode.*;


/**
 * Commande permettant au joueur de se déplacer vers une pièce voisine
 * dans la direction choisie. Cette classe implémente les interfaces
 * {@link Command} et {@link ActionListener} pour gérer le déplacement
 * et les interactions avec l'utilisateur.
 *
 * @author Marc Champesme
 * @version 18 avril 2026
 */
public class GoCommand implements Command, ActionListener {

    /** Référence vers le jeu en cours. */
    private Game theGame;

    /** Menu graphique pour sélectionner la direction de déplacement. */
    private ListView<Direction> dirMenu;

    /**
     * Construit une nouvelle commande de déplacement.
     *
     * @param theGame le jeu pour lequel cette commande est créée
     * @throws NullPointerException si le jeu est {@code null}
     */
    public GoCommand(Game theGame) {
        if (theGame == null) {
            throw new NullPointerException("Le jeu ne peut pas être null.");
        }
        this.theGame = theGame;
    }

    /**
     * Retourne une description de l'aide pour cette commande.
     * Explique comment choisir une direction pour se déplacer.
     *
     * @return une chaîne de caractères décrivant l'aide de la commande
     */
    @Override
    public String getHelp() {
        return "Choix d'une direction pour aller à une des pièces voisines de cette pièce";
    }

    /**
     * Exécute la commande de déplacement.
     * Crée un menu graphique affichant les directions possibles pour le déplacement.
     * Le menu permet à l'utilisateur de choisir une direction parmi les pièces voisines.
     *
     */
    @Override
    public void execute() {
        GameMap theMap = theGame.getMap();

        EnumMap<Direction, Location> nextLocs = theMap.nextValidLocationFrom(theGame.getCurrentLocation());

        JFrame theFrame = theGame.getFrame();

        dirMenu = ListView.builder(nextLocs.keySet())
        				.withGUI(theFrame, this)
        				.withSelectionMode(SINGLE_SELECTION)
                        .withTitle("Déplacement")
                        .withHeaderText("Déplacement vers ?")
                        .withFooterText(getHelp())
                        .build();
        dirMenu.showView();
    }

    /**
     *
     * Met à jour l'emplacement actuel du joueur en fonction de la direction choisie
     * et affiche un message de confirmation. Cette méthode est appelée lorsqu'une direction est sélectionnée dans le menu.
     *
     * @param e l'événement d'action déclenché par la sélection d'une direction
     */
    public void actionPerformed(ActionEvent e) {
        GameMap theMap = theGame.getMap();
        EnumMap<Direction, Location> nextLocs = theMap.nextValidLocationFrom(theGame.getCurrentLocation());

        Direction choice = dirMenu.getSelectedValue();
        if (choice == null) {
            throw new NullPointerException("Aucune direction sélectionnée.");
        }

        Location newLocation = nextLocs.get(choice);

        theGame.setCurrentLocation(newLocation);
        dirMenu.showNotificationMsg("Vous êtes maintenant dans la pièce: " +
                            theGame.getCurrentRoom().getLongDescriotion());
        theGame.showMenu();
    }

    /**
     * Retourne une représentation textuelle de cette commande.
     * Cette méthode fournit une description concise de la commande.
     *
     * @return une chaîne de caractères décrivant cette commande
     */
    @Override
    public String toString() {
        return "Aller à";
    }
}
