/**
 * 
 */
package poo2.zork.controller;

import static poo2.zork.view.SelectionMode.SINGLE_SELECTION;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;

import poo2.zork.model.ObjetZork;
import poo2.zork.model.room.Room;
import poo2.zork.view.ListView;


/**
 * Commande permettant de déposer un objet de l'inventaire du joueur
 * dans la pièce courante du jeu.
 * Cette classe implémente {@link Command} et {@link ActionListener}
 * pour gérer l'interaction avec l'utilisateur.
 *
 *
 * @author Marc Champesme
 * @version 18 avril 2026
 */
public class DropObjectCommand implements Command, ActionListener {

    /** Référence vers le jeu en cours. */
    private Game theGame;

    /** Menu graphique pour sélectionner l'objet à déposer. */
    private ListView<ObjetZork> objMenu;

    /**
     * Construit une nouvelle commande de dépôt d'objet pour un jeu donné.
     *
     * @param theGame le jeu pour lequel cette commande est créée
     * @throws NullPointerException si le jeu est {@code null}
     */
    public DropObjectCommand(Game theGame) {
        if (theGame == null) {
            throw new NullPointerException("Le jeu ne peut pas être null.");
        }
        this.theGame = theGame;
    }

    /**
     * Exécute la commande de dépôt d'objet.
     * Crée un menu graphique pour permettre à l'utilisateur de choisir
     * un objet à déposer. Si le joueur ne porte aucun objet, un message
     * d'alerte est affiché.
     */
    @Override
    public void execute() {
        JFrame theFrame = theGame.getFrame();
        objMenu = ListView.builder(theGame.getGamer())
        			.withGUI(theFrame, this)
        			.withSelectionMode(SINGLE_SELECTION)
                    .withTitle("Dépot d'un objet")
                    .withHeaderText("Choisissez un objet dans la liste:")
                    .withFooterText(getHelp())
                    .build();
        if (theGame.getGamer().isEmpty()) {
            objMenu.showAlertMsg("Vous ne portez aucun objet!");
            theGame.showMenu();
            return;
        }
        objMenu.showView();
    }

    /**
     *
     * Dépose l'objet sélectionné dans la pièce courante et met à jour
     * l'inventaire du joueur.
     *
     * @param e l'événement d'action déclenché par la sélection d'un objet
     * @throws NullPointerException si aucun objet n'est sélectionné
     */
    public void actionPerformed(ActionEvent e) {
        ObjetZork oz = objMenu.getSelectedValue();
        if (oz == null) {
            throw new NullPointerException("Aucun objet sélectionné.");
        }
        Room currentRoom = theGame.getCurrentRoom();
        theGame.getGamer().remove(oz);
        currentRoom.add(oz);
        objMenu.showNotificationMsg("Vous avez déposé l'objet " + oz.getNiceName()
                                    + " dans la pièce courante");
        theGame.showMenu();
    }

    /**
     * Retourne le texte de l'aide pour cette commande.
     *
     * @return une chaîne de caractères décrivant comment utiliser cette commande
     */
    @Override
    public String getHelp() {
        return "Il vous sera demandé de choisir l'objet à déposer dans la pièce courante";
    }

    /**
     * Retourne une représentation textuelle de cette commande.
     *
     * @return une chaîne de caractères décrivant cette commande
     */
    @Override
    public String toString() {
        return "Déposer un objet dans la pièce courante";
    }
}
