/**
 * 
 */
package poo2.zork.controller;

import static poo2.zork.view.SelectionMode.SINGLE_SELECTION;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;

import poo2.zork.model.Gamer;
import poo2.zork.model.ObjetZork;
import poo2.zork.model.room.Room;
import poo2.zork.view.ListView;

/**
 * Commande permettant au joueur de prendre un objet de la pièce courante
 * et de l'ajouter à son inventaire. Cette classe implémente les interfaces
 * {@link Command} et {@link ActionListener} pour gérer la prise d'objet
 * et les interactions avec l'utilisateur.
 *
 * @author Marc Champesme
 * @version 18 avril 2026
 */
public class TakeObjectCommand implements Command, ActionListener {

    /** Référence vers le jeu en cours. */
    private Game theGame;

    /** Menu graphique pour sélectionner l'objet à prendre. */
    private ListView<ObjetZork> objMenu;

    /** Référence vers la pièce courante. */
    private Room currentRoom;

    /**
     * Construit une nouvelle commande pour prendre un objet dans la pièce courante.
     *
     * @param theGame le jeu pour lequel cette commande est créée
     * @throws NullPointerException si le jeu est {@code null}
     */
    public TakeObjectCommand(Game theGame) {
        if (theGame == null) {
            throw new NullPointerException("Le jeu ne peut pas être null.");
        }
        this.theGame = theGame;
    }

    /**
     * Exécute la commande pour prendre un objet.
     * Crée un menu graphique affichant la liste des objets présents dans la pièce courante.
     * Si la pièce ne contient aucun objet, un message d'alerte est affiché.
     *
     */
    @Override
    public void execute() {
        currentRoom = theGame.getCurrentRoom();

        JFrame theFrame = theGame.getFrame();

        objMenu = ListView.builder(currentRoom)
        				.withGUI(theFrame, this)
        				.withSelectionMode(SINGLE_SELECTION)
                        .withTitle("Prendre un objet")
                        .withHeaderText("Choisissez un objet dans la liste:")
                        .withFooterText(getHelp())
                        .build();

        if (currentRoom.isEmpty()) {
            objMenu.showAlertMsg("Il n'y a aucun objet dans cette pièce");
            theGame.showMenu();
            return;
        }
        objMenu.showView();
    }

    /**
     *
     * Ajoute l'objet sélectionné à l'inventaire du joueur si possible,
     * sinon affiche un message d'erreur approprié. Méthode appelée lorsqu'un objet est sélectionné dans le menu.
     *
     * @param e l'événement d'action déclenché par la sélection d'un objet
     * @throws NullPointerException si aucun objet n'est sélectionné
     */
    public void actionPerformed(ActionEvent e) {
        ObjetZork oz = objMenu.getSelectedValue();
        if (oz == null) {
            throw new NullPointerException("Aucun objet sélectionné.");
        }

        Room currentRoom = theGame.getCurrentRoom();

        Gamer theGamer = theGame.getGamer();

        if (theGamer.canAdd(oz)) {
            theGamer.add(oz);
            currentRoom.remove(oz);
            objMenu.showNotificationMsg("Vous avez pris l'objet " + oz.getNiceName()
                                + " dans la pièce courante");
        } else {
            if (oz.isTransportable()) {
                objMenu.showAlertMsg("Impossible de prendre l'objet " + oz.getNiceName()
                                    + " dans la pièce courante:\n"
                                    + "Vous portez déjà trop d'objets");
            } else {
                objMenu.showAlertMsg("Impossible de prendre l'objet " + oz.getNiceName()
                                    + " dans la pièce courante:\n"
                                    + "Il n'est pas transportable");
            }
        }
        theGame.showMenu();
    }

    /**
     * Retourne un texte l'aide pdur cette commande.
     * Explique comment choisir un objet à prendre dans la pièce courante.
     *
     * @return une chaîne de caractères décrivant l'aide de la commande
     */
    @Override
    public String getHelp() {
        return "Il vous sera demandé de choisir l'objet à prendre dans la pièce courante";
    }

    /**
     * Retourne une représentation textuelle de cette commande.
     * Cette méthode fournit une description concise de la commande.
     *
     * @return une chaîne de caractères décrivant cette commande
     */
    @Override
    public String toString() {
        return "Prendre un objet dans la pièce courante";
    }
}
