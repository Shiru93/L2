/**
 * 
 */
package poo2.zork.controller;

/**
 * Interface représentant une commande exécutable.
 * Une commande fournit une aide descriptive, peut être exécutée,
 * et possède une représentation textuelle.
 *
 * @author Marc Champesme
 * @version 18 avril 2026
 */
public interface Command {

    /**
     * Retourne une description ou une aide sur la commande.
     * Cette méthode doit fournir une explication claire de ce que fait la commande
     * et de comment elle doit être utilisée.
     *
     * @return une chaîne de caractères décrivant la commande
     */
    public String getHelp();

    /**
     * Exécute la commande.
     * Cette méthode contient la logique principale de la commande.
     *
     */
    public void execute();

    /**
     * Retourne une représentation textuelle de la commande.
     * Cette méthode doit fournir une description concise de la commande,
     * utile pour l'affichage ou le débogage.
     *
     * @return une chaîne de caractères représentant la commande
     */
    public String toString();
}
