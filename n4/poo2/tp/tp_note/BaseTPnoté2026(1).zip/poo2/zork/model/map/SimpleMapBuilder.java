/**
 * 
 */
package poo2.zork.model.map;

import static poo2.zork.model.Direction.*;
import static poo2.zork.model.ObjetZork.*;

import poo2.zork.model.Location;
import poo2.zork.model.room.SimpleRoomBuilder;

/**
 * 
 */
public class SimpleMapBuilder extends GameMapBuilder<SimpleMapBuilder> {
	/**
	 * 
	 */
	public SimpleMapBuilder() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public SimpleMapBuilder self() {
		return this;
	}

	@Override
	public GameMap build() {
		GameMap newGameMap = new GameMap(this);
		Location entry = getEntranceLocation();
		newGameMap.put(entry, new SimpleRoomBuilder("Entrée", "C'est par là qu'on commence").withObject(LAMPE).build());
		Location loc = entry.nextLocation(EAST);
		newGameMap.put(loc, new SimpleRoomBuilder("Amphi D", "C'est cours de POO").withObject(LAMPE).withObject(CHAISE)
				.withObject(TABLE).build());
		loc = loc.nextLocation(EAST);
		newGameMap.put(loc, new SimpleRoomBuilder("Salle TP", "Un peu de pratique maintenant").withObject(CHAISE)
				.withObject(TABLE).withObject(ORDINATEUR).build());
		loc = loc.nextLocation(EAST);
		newGameMap.put(loc,
				new SimpleRoomBuilder("Salle du trésor", "C'est ici que l'on gagne!").withObject(TRESOR).build());
		loc = entry.nextLocation(NORTH);
		newGameMap.put(loc, new SimpleRoomBuilder("Jardin", "Un peu de verdure").build());
		loc = loc.nextLocation(SOUTH);
		newGameMap.put(loc, new SimpleRoomBuilder("Salle TD", "C'est ici qu'on prépare le TP").withObject(CHAISE)
				.withObject(TABLE).build());

		return newGameMap;
	}

}
