/**
 *
 */
package poo2.zork.model.room;

/**
 * 
 */
public class SimpleRoomBuilder extends RoomBuilder<SimpleRoomBuilder> {
	private boolean hasNext;

	/**
	 * 
	 */
	public SimpleRoomBuilder(String shortName, String description) {
		super(shortName, description);
		hasNext = true;
	}

	@Override
	boolean hasNext() {
		boolean result = hasNext;
		hasNext = false;
		return result;
	}

	@Override
	public SimpleRoomBuilder self() {
		return this;
	}

	@Override
	public Room build() {
		return new Room(getName(), getDescription(), getZorkObjects());
	}

}
