/**
 * 
 */
package poo2.zork.model.room;

import java.util.Random;

import poo2.zork.model.ObjetZork;

/**
 * 
 */
public class RandomRoomBuilder extends RoomBuilder<RandomRoomBuilder> {
	private static Random rand = new Random();
	private int maxObjectNumber = 10;
	private int roomCounter;
	private int maxRoomCopiesNb;

	public RandomRoomBuilder(String shortName, String description) {
		super(shortName, description);
		roomCounter = -1;
		maxRoomCopiesNb = -1;
	}

	public RandomRoomBuilder(String shortName, String description, int roomNb) {
		super(shortName, description);
		roomCounter = 1;
		maxRoomCopiesNb = roomNb;
	}

	@Override
	public boolean hasNext() {
		return roomCounter <= maxRoomCopiesNb;
	}

	public int getMaxRoomCopiesNb() {
		return this.maxRoomCopiesNb;
	}

	@Override
	public RandomRoomBuilder self() {
		return this;
	}

	public RandomRoomBuilder withMaxObjectNb(int n) {
		this.maxObjectNumber = n;
		return self();
	}

	@Override
	public Room build() {
		roomCounter++;
		if (maxRoomCopiesNb > 0) {
			int objNb = rand.nextInt(maxObjectNumber);
			while (getOzNb() < objNb) {
				withObject(ObjetZork.getRandomInstance());
			}
			return new Room(getName() + " n°" + roomCounter, getDescription(), getZorkObjects());
		}
		return new Room(getName(), getDescription(), getZorkObjects());
	}

}
