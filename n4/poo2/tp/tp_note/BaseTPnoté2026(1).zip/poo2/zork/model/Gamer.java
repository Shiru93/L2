/**
 * 
 */
package poo2.zork.model;

/**
 * 
 */
public class Gamer extends ObjetZorkContainer {
	public static final int MAX_WEIGHT = 200;
	private String myName;
	private String description;

	public Gamer(String shortName, String description) {
		myName = shortName;
		this.description = description;
	}

	@Override
	public boolean canAdd(ObjetZork obj) {
		return (getWeight() +obj.getWeight() <= MAX_WEIGHT) && obj.isTransportable();
	}
	
	public int getWeight() {
		int weight = 0;
		for (ObjetZork oz : this) {
			weight += oz.getWeight();
		}
		return weight;
	}
	
	public String getLongDescriotion() {
		return myName + ": " + description;
	}

}
