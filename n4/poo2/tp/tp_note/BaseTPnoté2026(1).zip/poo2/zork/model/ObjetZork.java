/**
 * 
 */
package poo2.zork.model;

import java.util.Random;

/**
 * L'énumération {@code ObjetZork} représente les différents objets que l'on peut trouver
 * ou avec lesquels on peut interagir dans le jeu Zork.
 * Chaque objet possède un nom descriptif, un poids et une propriété indiquant s'il
 * est transportable par le joueur.
 */
public enum ObjetZork {
    CHAISE("Chaise", 10, true),
    TABLE("Table", 50, false),
    ORDINATEUR("Mon PC", 15, true),
    PIZZA("Pizza 4 fromages", 5, true),
    TRESOR("Mon précieux", 100, true),
    CLEF("Clé de la salle au trésor", 2, true),
    LAMPE("Lampe de poche", 5, true);

	private static Random rand = new Random();
	
	public static ObjetZork getRandomInstance() {
		ObjetZork[] allInstances = values();
		return allInstances[rand.nextInt(allInstances.length)];
	}
	
    /**
     * Le nom descriptif de l'objet, tel qu'il s'affichera pour l'utilisateur.
     */
    private final String niceName;

    /**
     * Le poids de l'objet en unités arbitraires.
     */
    private final int weight;

    /**
     * Indique si l'objet peut être transporté par le joueur.
     * Si la valeur est {@code false}, l'objet est considéré comme statique ou trop lourd.
     */
    private final boolean isTransportable;

    /**
     * Constructeur de l'énumération {@code ObjetZork}.
     *
     * @param niceName Le nom descriptif de l'objet. Ne peut pas être {@code null}.
     * @param weight Le poids de l'objet. Doit être strictement supérieur à 0.
     * @param isTransportable Indique si l'objet peut être transporté.
     * @throws NullPointerException si le paramètre {@code niceName} est {@code null}.
     * @throws IllegalArgumentException si le paramètre {@code weight} est inférieur ou égal à 0.
     */
    ObjetZork(String niceName, int weight, boolean isTransportable) {
        if (niceName == null) {
            throw new NullPointerException();
        }
        if (weight <= 0) {
            throw new IllegalArgumentException();
        }
        this.niceName = niceName;
        this.weight = weight;
        this.isTransportable = isTransportable;
    }

    /**
     * Retourne le nom descriptif de l'objet.
     *
     * @return Le nom descriptif de l'objet.
     */
    public String getNiceName() {
        return this.niceName;
    }

    /**
     * Retourne le poids de l'objet.
     *
     * @return Le poids de l'objet.
     */
    public int getWeight() {
        return this.weight;
    }

    /**
     * Indique si l'objet peut être transporté.
     *
     * @return {@code true} si l'objet est transportable, {@code false} sinon.
     */
    public boolean isTransportable() {
        return this.isTransportable;
    }
}
