/**
 * 
 */
package poo2.zork.model.map;

import java.util.LinkedList;
import java.util.List;

import poo2.zork.model.Location;
import poo2.zork.model.room.RandomRoomBuilder;

/**
 * 
 */
public class RandomMapBuilder extends GameMapBuilder<RandomMapBuilder> {
	private List<RandomRoomBuilder> builderList;

	public RandomMapBuilder() {
		builderList = new LinkedList<>();
	}

	public RandomMapBuilder withNcopiesOfRoom(String roomName, String roomDesc, int nb) {
		builderList.add(new RandomRoomBuilder(roomName, roomDesc, nb));
		return self();
	}

	@Override
	public RandomMapBuilder self() {
		return this;
	}

	@Override
	public GameMap build() {
		GameMap newGameMap = new GameMap(this);
		Location loc = getEntranceLocation();
		newGameMap.put(loc, new RandomRoomBuilder("Entrée", "C'est ici que tout commence").build());

		for (RandomRoomBuilder builder : builderList) {
			while (builder.hasNext() && newGameMap.size() < this.getRoomNb()) {
				newGameMap.addNext(builder.build());
			}
		}

		return newGameMap;
	}

}
