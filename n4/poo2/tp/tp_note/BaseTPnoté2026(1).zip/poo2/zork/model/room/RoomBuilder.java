/**
 * 
 */
package poo2.zork.model.room;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;

import poo2.zork.model.ObjetZork;

/**
 * 
 */
public abstract class RoomBuilder<T extends RoomBuilder<T>> {
	private String shortName;
	private String description;
	private Collection<ObjetZork> theObjects;

	/**
	 * 
	 */
	public RoomBuilder(String shortName, String description) {
		this.shortName = shortName;
		this.description = description;
		theObjects = new LinkedList<>();
	}

	String getName() {
		return this.shortName;
	}

	String getDescription() {
		return this.description;
	}

	abstract boolean hasNext();

	Collection<ObjetZork> getZorkObjects() {
		return Collections.unmodifiableCollection(theObjects);
	}

	int getOzNb() {
		return theObjects.size();
	}

	public T withObject(ObjetZork oz) {
		theObjects.add(oz);
		return self();
	}

	public abstract T self();

	public abstract Room build();
}
