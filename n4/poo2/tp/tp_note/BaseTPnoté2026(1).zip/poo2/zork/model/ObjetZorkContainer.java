/**
 * 
 */
package poo2.zork.model;

import static poo2.zork.model.ObjetZork.CHAISE;
import static poo2.zork.model.ObjetZork.LAMPE;
import static poo2.zork.model.ObjetZork.ORDINATEUR;

import java.util.Collection;
import java.util.Iterator;

import poo2.util.EnumCollection;
import poo2.zork.model.room.Room;
/**
 * 
 */
public abstract class ObjetZorkContainer extends EnumCollection<ObjetZork> {
	public static void main(String[] args) {
		System.out.println("Début");
		ObjetZorkContainer c = new Room("Test Room", "Test");
		c.add(CHAISE);
		c.add(CHAISE);
		c.add(LAMPE);
		c.add(LAMPE);
		c.add(LAMPE);
		c.add(LAMPE);
		c.add(ORDINATEUR);
		System.out.println(c);
		System.out.println("Avec itérateur et remove:");
		Iterator<ObjetZork> iter = c.iterator();
		System.out.println(iter.next());
		System.out.println("remove:");
		iter.remove();
		System.out.println(iter.next());
		System.out.println(iter.next());
		System.out.println("remove:");
		iter.remove();
		System.out.println(iter.next());
		System.out.println(iter.next());
		System.out.println(iter.next());
		System.out.println(c);


	}
	
	public ObjetZorkContainer() {
		super(ObjetZork.class);
	}

	public ObjetZorkContainer(Collection<ObjetZork> c) {
		super(ObjetZork.class, c);
		for (ObjetZork oz : c) {
			if (oz == null) {
				throw new NullPointerException();
			}
			if (!canAdd(oz)) {
				throw new IllegalStateException();
			}
		}
	}

	public abstract boolean canAdd(ObjetZork obj);

	@Override
	public boolean add(ObjetZork oz) {
		if (oz == null) {
			throw new NullPointerException();
		}
		if (!canAdd(oz)) {
			throw new IllegalStateException();
		}
		return super.add(oz);
	}


}
