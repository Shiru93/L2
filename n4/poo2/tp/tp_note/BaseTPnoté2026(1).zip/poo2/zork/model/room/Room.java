/**
 * 
 */
package poo2.zork.model.room;

import java.util.Collection;

import poo2.zork.model.ObjetZork;
import poo2.zork.model.ObjetZorkContainer;

/**
 * 
 */
public class Room extends ObjetZorkContainer {
	private String myName;
	private String description;

	public Room(String shortName, String description) {
		myName = shortName;
		this.description = description;
	}
	
	public Room(String shortName, String description, Collection<ObjetZork> c) {
		super(c);
		myName = shortName;
		this.description = description;
	}

	public Room(RoomBuilder<?> builder) {
		super(builder.getZorkObjects());
		myName = builder.getName();
		description = builder.getDescription();
	}
	
	@Override
	public boolean canAdd(ObjetZork obj) {
		return obj != null;
	}
	
	public String getLongDescriotion() {
		return myName + ": " + description;
	}

	@Override
	public String toString() {
		return "Room:" + myName;
	}
}
