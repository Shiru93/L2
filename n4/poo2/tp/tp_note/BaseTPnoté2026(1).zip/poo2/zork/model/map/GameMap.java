/**
 * 
 */
package poo2.zork.model.map;

import java.util.EnumMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Optional;
import java.util.Set;

import poo2.zork.model.Location;
import poo2.zork.model.Direction;
import poo2.zork.model.room.Room;

/**
 * 
 */
public class GameMap implements Iterable<Room> {
	private int lineNb = 10;
	private int colNb = 10;
	private Location entranceLocation;
	private Room[][] map;
	private int size;
	private Set<Location> nextFreeLocations;

	GameMap(GameMapBuilder<?> builder) {
		this.colNb = builder.getColNb();
		this.lineNb = builder.getLineNb();
		this.entranceLocation = builder.getEntranceLocation();
		map = new Room[this.colNb][this.lineNb];
		this.nextFreeLocations = new HashSet<>();
	}

	public int getLineNb() {
		return this.lineNb;
	}

	public int getColNb() {
		return this.colNb;
	}

	public Location getEntranceLocation() {
		return entranceLocation;
	}

	public Optional<Room> get(Location loc) {
		return Optional.ofNullable(map[loc.getColumn()][loc.getLine()]);
	}

	public Optional<Room> put(Location loc, Room p) {
		if (loc == null || p == null) {
			throw new NullPointerException();
		}
		if (!hasValidLocation(loc)) {
			throw new IllegalArgumentException();
		}
		Optional<Room> oldRoom = get(loc);
		map[loc.getColumn()][loc.getLine()] = p;
		if (oldRoom.isEmpty()) {
			size++;
		}
		nextFreeLocations.addAll(nextFreeLocationFrom(loc).values());
		nextFreeLocations.remove(loc);
		return oldRoom;
	}

	public Optional<Location> addNext(Room r) {
		if (nextFreeLocations.isEmpty()) {
			return Optional.empty();
		}
		Iterator<Location> iter = nextFreeLocations.iterator();
		Location loc = iter.next();
		put(loc, r);
		return Optional.of(loc);
	}
	public boolean hasValidLocation(Location loc) {
		return loc.getLine() >= 0 && loc.getLine() < lineNb && loc.getColumn() >= 0 && loc.getColumn() < colNb;
	}

	public EnumMap<Direction, Location> nextValidLocationFrom(Location loc) {
		EnumMap<Direction, Location> nextLocMap = new EnumMap<>(Direction.class);
		for (Direction d : Direction.values()) {
			Location nextLoc = loc.nextLocation(d);
			if (hasValidLocation(nextLoc) && get(nextLoc).isPresent()) {
				nextLocMap.put(d, nextLoc);
			}

		}
		return nextLocMap;
	}

	public EnumMap<Direction, Location> nextFreeLocationFrom(Location loc) {
		EnumMap<Direction, Location> nextLocMap = new EnumMap<>(Direction.class);
		for (Direction d : Direction.values()) {
			Location nextLoc = loc.nextLocation(d);
			if (hasValidLocation(nextLoc) && get(nextLoc).isEmpty()) {
				nextLocMap.put(d, nextLoc);
			}
		}
		return nextLocMap;
	}

	@Override
	public Iterator<Room> iterator() {
		// TODO Auto-generated method stub
		return null;
	}

	public int size() {
		return size;
	}
}
