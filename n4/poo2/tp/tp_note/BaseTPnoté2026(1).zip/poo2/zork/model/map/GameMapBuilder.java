package poo2.zork.model.map;

import poo2.zork.model.Location;

public abstract class GameMapBuilder<T extends GameMapBuilder<T>> {
	private int lineNb = 10;
	private int colNb = 10;
	private int roomNb = 10;
	private Location entranceLocation;

	public GameMapBuilder() {
		entranceLocation = Location.getInstance(0, lineNb / 2);
	}

	int getLineNb() {
		return this.lineNb;
	}

	int getColNb() {
		return this.colNb;
	}

	Location getEntranceLocation() {
		return entranceLocation;
	}

	int getRoomNb() {
		return this.roomNb;
	}

	public T withLineNb(int lineNb) {
		this.lineNb = lineNb;
		return self();
	}

	public T withColNb(int colNb) {
		this.colNb = colNb;
		return self();
	}

	public T withRoomNb(int nb) {
		this.roomNb = nb;
		return self();
	}
	
	public T withEntranceLocation(Location loc) {
		this.entranceLocation = loc;
		return self();
	}

	public abstract T self();

	public abstract GameMap build();

}
