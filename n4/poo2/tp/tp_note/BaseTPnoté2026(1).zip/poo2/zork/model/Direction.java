package poo2.zork.model;

public enum Direction {
	NORTH, EAST, SOUTH, WEST
}
