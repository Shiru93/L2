/**
 * 
 */
package poo2.zork.model;


/**
 * 
 */
public class Location {
	private static int colNb = 10;
	private static int lineNb = 10;
	private static Location[][] cachedInstances = new Location[colNb][lineNb];
	
	public static Location getInstance(int column, int line) {
		if (column >= 0 && column < colNb && line >= 0 && line < lineNb) {
			if (cachedInstances[column][line] == null) {
				cachedInstances[column][line] = new Location(column, line);
			}
			return cachedInstances[column][line];
		}
		return new Location(column, line);
	}
	private int line;
	private int column;


	/**
	 * 
	 */
	private Location(int column, int line) {
		this.line = line;
		this.column = column;
	}

	public int getLine() {
		return this.line;
	}

	public int getColumn() {
		return this.column;
	}

	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof Location)) {
			return false;
		}
		Location loc = (Location) obj;
		return loc.line == line && loc.column == column;
	}

	public int hashCode() {
		return line * 31 + column;
	}

	public String toString() {
		return "[" + column + ", " + line + "]";
	}

	public Location nextLocation(Direction d) {
		switch (d) {
		case NORTH:
			return getInstance(column, line - 1);
		case EAST:
			return getInstance(column + 1, line);
		case SOUTH:
			return getInstance(column, line + 1);
		case WEST:
			return getInstance(column - 1, line);
		}
		return null; // impossible
	}

}
