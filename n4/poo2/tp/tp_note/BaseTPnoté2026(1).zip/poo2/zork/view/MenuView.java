package poo2.zork.view;

import java.io.Console;
import java.util.List;

/**
 * Vue en mode texte pour afficher et interagir avec une liste d'éléments. Une
 * instance de cette classe peut-être créée à l'aide d'un ListViewBuilder obtenu
 * grâce à la méthode builder de l'interface ListView.
 *
 * @param <E> le type des éléments de la liste
 * 
 * @author Marc Champesme
 * @version 18 avril 2026
 * 
 */
class MenuView<E> extends AbstractListView<E> {

	/**
	 * Construit une nouvelle vue de menu à partir d'un builder.
	 *
	 * @param builder le builder contenant les éléments et les informations de la
	 *                vue
	 * @throws NullPointerException si le builder est {@code null}
	 */
	MenuView(GUIViewBuilder<E> builder) {
		super(builder);
	}

	/**
	 * Affiche la vue du menu dans la console. Efface l'écran, affiche le titre,
	 * l'en-tête et la liste des éléments numérotés. Si la liste est vide, affiche
	 * un message d'alerte.
	 */
	@Override
	public void showView() {
		System.out.print("\033[H\033[2J"); // Efface l'écran
		System.out.flush();
		System.out.println(getTitle());
		if (isEmpty()) {
			showAlertMsg("Erreur: liste de choix vide");
			return;
		}
		System.out.println(getHeaderText());
		System.out.println();
		int i = 0;
		for (E elt : this) {
			System.out.println("\t" + i + " : " + elt);
			i++;
		}
	}

	/**
	 * Permet à l'utilisateur de sélectionner un élément de la liste via la console.
	 * Demande à l'utilisateur d'entrer le numéro de l'élément souhaité.
	 *
	 * @return l'élément sélectionné, ou {@code null} si la console n'est pas
	 *         disponible ou si une erreur survient
	 */
	@Override
	public E getSelectedValue() {
		Console cons = System.console();
		if (cons == null) {
			showErrorMsg("Erreur: console non disponible");
			return null;
		}
		int choice = -1;
		while (choice < 0 || choice >= size()) {
			System.out.print("Entrez le numéro de l'item choisi (entre 0 et " + (size() - 1) + ") --> ");
			String line = cons.readLine();
			try {
				choice = Integer.parseInt(line);
			} catch (NumberFormatException e) {
				showAlertMsg("Erreur: vous devez entrer un chiffre entre 0 et " + (size() - 1));
				choice = -1;
			}
		}
		return get(choice);
	}

	@Override
	public List<E> getSelectedValuesList() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * Affiche un message de notification à l'utilisateur dans la console. Attend
	 * que l'utilisateur appuie sur une touche pour continuer.
	 *
	 * @param msg le message à afficher
	 * @throws NullPointerException si le message est {@code null}
	 */
	@Override
	public void showNotificationMsg(String msg) {
		if (msg == null) {
			throw new NullPointerException("Le message ne peut pas être null.");
		}
		System.out.println(msg);
		System.out.println("Tapez une touche pour continuer...");
		System.console().readLine();
	}

	/**
	 * Affiche un message d'alerte à l'utilisateur dans la console. Attend que
	 * l'utilisateur appuie sur une touche pour continuer.
	 *
	 * @param msg le message d'alerte à afficher
	 * @throws NullPointerException si le message est {@code null}
	 */
	@Override
	public void showAlertMsg(String msg) {
		if (msg == null) {
			throw new NullPointerException("Le message ne peut pas être null.");
		}
		System.out.println("Avertissement: " + msg);
		System.out.println("Tapez une touche pour continuer...");
		System.console().readLine();
	}

	/**
	 * Affiche un message d'erreur à l'utilisateur dans la console. Attend que
	 * l'utilisateur appuie sur une touche pour continuer.
	 *
	 * @param msg le message d'erreur à afficher
	 * @throws NullPointerException si le message est {@code null}
	 */
	@Override
	public void showErrorMsg(String msg) {
		if (msg == null) {
			throw new NullPointerException("Le message ne peut pas être null.");
		}
		System.err.println("Error: " + msg);
		System.out.println("Tapez une touche pour continuer...");
		System.console().readLine();
	}

	/**
	 * Affiche un message informatif à l'utilisateur dans la console.
	 *
	 * @param msg le message informatif à afficher
	 * @throws NullPointerException si le message est {@code null}
	 */
	@Override
	public void showInfoMsg(String msg) {
		if (msg == null) {
			throw new NullPointerException("Le message ne peut pas être null.");
		}
		System.out.println(msg);
	}

}
