package poo2.zork.view;

import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTextArea;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;

import static poo2.zork.view.SelectionMode.*;

/**
 * Builder pour construire une {@link ListView}. Si la méthode whithGUI spécifie
 * un environnement graphique, construit une instance de GUIView, dans le cas
 * contraire une instance de MenuView est créée.
 *
 * @param <E> le type des éléments de la liste
 * 
 * @author Marc Champesme
 * @version 18 avril 2026
 */
class GUIViewBuilder<E> implements ListViewBuilder<E> {
	JFrame theFrame;
	private ActionListener listener;
	private SelectionMode selMode = SINGLE_SELECTION;

	/** Titre de la vue de liste. Par défaut, une chaîne de quatre espaces. */
	String title = "    ";

	/**
	 * Texte à afficher sous le titre (en-tête). Par défaut, une chaîne de quatre
	 * espaces.
	 */
	String header = "    ";

	/** Liste des objets à afficher pour le choix. */
	List<E> elements;

	/**
	 * Texte à afficher sous la liste (pied de page). Par défaut, une chaîne de
	 * quatre espaces.
	 */
	String footer = "    ";

	/** Panneau principal contenant les composants de l'interface. */
	JPanel myPanel;

	/** Composant graphique représentant la liste des éléments. */
	JList<E> list;

	/** Bouton d'exécution associé à la sélection d'un élément. */
	JButton execButton;

	/**
	 * Construit un nouveau builder pour une vue graphique avec une fenêtre, un
	 * écouteur d'action, et une collection d'éléments.
	 *
	 * @param aFrame   la fenêtre principale de l'interface graphique
	 * @param listener l'écouteur d'action pour le bouton d'exécution
	 * @param c        un itérable contenant les éléments à ajouter à la liste
	 * @throws NullPointerException si l'un des paramètres est {@code null}
	 */
	public GUIViewBuilder(Iterable<E> c) {
		if (c == null) {
			throw new NullPointerException("L'itérable ne peut pas être null.");
		}
		elements = new ArrayList<E>();
		for (E elt : c) {
			elements.add(elt);
		}
	}

	/**
	 * Spécifie le mode de sélection appliqué à cette vue. Si cette méthode nest pas
	 * appelée le mode de sélection par défaut est SINGLE_SELECTION.
	 * 
	 * @param mode mode de sélection à appliquer
	 * 
	 * @return le builder courant pour permettre le chaînage des méthodes
	 * 
	 * @throws NullPointerException si un des arguments spécifiés est {@code null}
	 */
	public ListViewBuilder<E> withSelectionMode(SelectionMode mode) {
		if (mode == null) {
			throw new NullPointerException("Le mode de sélection ne peut pas être null.");

		}
		selMode = mode;
		return this;
	}

	/**
	 * Spécifie la fenêtre principale de l'application et l'écouteur d'action si la
	 * ListView doit s'inscrire dans une application avec interface graphique.
	 *
	 * @param frame    la fenêtre principale de l'application
	 * @param listener écouteur d'action qui exécute l'action souhaitée
	 * 
	 * @return le builder courant pour permettre le chaînage des méthodes
	 * @throws NullPointerException si un des arguments spécifiés est {@code null}
	 */
	public ListViewBuilder<E> withGUI(JFrame frame, ActionListener listener) {
		if (frame == null || listener == null) {
			throw new NullPointerException("ne peut pas être null.");
		}
		theFrame = frame;
		this.listener = listener;
		return this;
	}

	/**
	 * Définit le titre de la vue de liste.
	 *
	 * @param s le titre à définir
	 * @return le builder courant pour permettre le chaînage des méthodes
	 * @throws NullPointerException si le titre {@code s} est {@code null}
	 */
	public ListViewBuilder<E> withTitle(String s) {
		if (s == null) {
			throw new NullPointerException("Le titre ne peut pas être null.");
		}
		title = s;
		return this;
	}

	/**
	 * Définit le texte de l'en-tête de la vue de liste.
	 *
	 * @param s le texte de l'en-tête à définir
	 * @return le builder courant pour permettre le chaînage des méthodes
	 * @throws NullPointerException si le texte de l'en-tête {@code s} est
	 *                              {@code null}
	 */
	public ListViewBuilder<E> withHeaderText(String s) {
		if (s == null) {
			throw new NullPointerException("Le texte de l'en-tête ne peut pas être null.");
		}
		header = s;
		return this;
	}

	/**
	 * Définit le texte du pied de page de la vue de liste.
	 *
	 * @param s le texte du pied de page à définir
	 * @return le builder courant pour permettre le chaînage des méthodes
	 * @throws NullPointerException si le texte du pied de page {@code s} est
	 *                              {@code null}
	 */
	public ListViewBuilder<E> withFooterText(String s) {
		if (s == null) {
			throw new NullPointerException("Le texte du pied de page ne peut pas être null.");
		}
		footer = s;
		return this;
	}

	/**
	 * Construit et retourne une nouvelle instance de {@link GUIView} configurée
	 * avec les paramètres actuels du builder.
	 *
	 * @return une nouvelle instance de {@link GUIView}
	 * @throws NullPointerException si un des éléments de la liste est {@code null}
	 */
	@Override
	public ListView<E> build() {
		if (theFrame == null || listener == null) {
			return new MenuView<>(this);
		}
		// Création d'un panel pour regrouper tous les éléments de l'interface placé
		// dans la JFrame
		myPanel = new JPanel(new BorderLayout());

		// Création d'une zone de texte au-dessus de la liste des choix
		JTextArea headerText = new JTextArea(header, 3, 10);
		// Avec une marge autour de la zone
		headerText.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		// Positionnement du headerText en haut (nord) de la vue:
		myPanel.add(headerText, BorderLayout.NORTH);

		// Création du composant liste
		DefaultListModel<E> listModel = new DefaultListModel<>();
		for (E elt : elements) {
			if (elt == null) {
				throw new NullPointerException("Aucun élément de la liste ne peut être null.");
			}
			listModel.addElement(elt);
		}
		list = new JList<>(listModel);
		if (selMode == MULTIPLE_SELECTION) {
			list.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		} else {
			list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		}
		list.setVisibleRowCount(6);

		// Placement de la liste dans un scrollPanel:
		JScrollPane listScrollPane = new JScrollPane(list);
		listScrollPane.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		// Placement de la liste au centre de la vue:
		myPanel.add(listScrollPane, BorderLayout.CENTER);

		// La zone du bas de la vue contient deux éléments:
		// - une zone de texte footerText
		// - et le bouton pour déclencher l'action
		JPanel footerPane = new JPanel();
		footerPane.setLayout(new BoxLayout(footerPane, BoxLayout.Y_AXIS));

		// Ajout d'une zone de texte en dessous de la liste
		JTextArea footerText = new JTextArea(footer, 3, 10);
		footerPane.add(footerText);

		// Ajout d'espacements et d'un séparateur
		footerPane.add(Box.createVerticalStrut(5));
		footerPane.add(new JSeparator(SwingConstants.HORIZONTAL));
		footerPane.add(Box.createVerticalStrut(5));

		// Le bouton qui va déclencher l'action:
		execButton = new JButton("Ok");
		execButton.setActionCommand("Exec");
		execButton.addActionListener(listener);
		execButton.setEnabled(selMode == NO_SELECTION); // Activation initiale du bouton
														// uniquement si la vue ne demande pas de sélection
		footerPane.add(execButton);

		// Ajout d'une marge tout autour du footerPanel:
		footerPane.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

		// Placement du footerPanel en bas de la vue:
		myPanel.add(footerPane, BorderLayout.PAGE_END);

		return new GUIView<>(this);
	}
}
