package poo2.zork.view;

import java.util.List;

/**
 * Permet d'afficher une liste d'objets et de sélectionner un objet parmi
 * ceux-ci.
 *
 * @param <E> le type des éléments affichés
 * 
 * @author Marc Champesme
 * @version 18 avril 2026
 */
public interface ListView<E> extends Iterable<E> {
	/**
	 * Retourne un builder permettant de créer une ListView.
	 * 
	 * @param <T> le type des éléments de la liste
	 * @param c   les éléments à afficher
	 * 
	 * @return un builder permettant de créer une ListView
	 * 
	 * @throws NullPointerException si l'iterable spécifié est null
	 */
	public static <T> ListViewBuilder<T> builder(Iterable<T> c) {
		return new GUIViewBuilder<>(c);
	}

	/**
	 * Retourne le titre de la vue de liste.
	 *
	 * @return le titre de la vue
	 */
	public String getTitle();

	/**
	 * Retourne le texte de l'en-tête de la vue de liste.
	 *
	 * @return le texte de l'en-tête
	 */
	public String getHeaderText();

	/**
	 * Retourne le texte du pied de page de la vue de liste.
	 *
	 * @return le texte du pied de page
	 */
	public String getFooterText();

	/**
	 * Affiche le menu sous forme d'une liste numérotée.
	 */
	public void showView();

	/**
	 * Affiche le message spécifié comme une information à l'utilisateur.
	 *
	 * @param msg message d'information à afficher
	 * @throws NullPointerException si le message est {@code null}
	 */
	public void showInfoMsg(String msg);

	/**
	 * Affiche le message spécifié comme une notification à l'utilisateur.
	 *
	 * @param msg message de notification à afficher
	 * @throws NullPointerException si le message est {@code null}
	 */
	public void showNotificationMsg(String msg);

	/**
	 * Affiche le message spécifié comme un avertissement à l'utilisateur.
	 *
	 * @param msg message d'avertissement à afficher
	 * @throws NullPointerException si le message est {@code null}
	 */
	public void showAlertMsg(String msg);

	/**
	 * Affiche le message spécifié comme une erreur indépendante de l'utilisateur.
	 *
	 * @param msg message d'erreur à afficher
	 * @throws NullPointerException si le message est {@code null}
	 */
	public void showErrorMsg(String msg);

	/**
	 * Demande à l'utilisateur de choisir un objet parmi la liste d'objets affichés
	 * et renvoie l'objet sélectionné.
	 *
	 * @return l'objet choisi par l'utilisateur, ou {@code null} si aucun objet
	 *         n'est sélectionné
	 */
	public E getSelectedValue();

	/**
	 * Retourne la liste des objets sélectionnés par l'utilisateur. Si le mode de
	 * sélection est SINGLE_SELECTION, la liste renvoyée contient l'unique éléments
	 * sélectionné. Si aucun élément n'est sélectionné renvoie une liste vide.
	 * 
	 * @return la liste des objets sélectionnés par l'utilisateur
	 */
	public List<E> getSelectedValuesList();

	/**
	 * Retourne le nombre d'éléments dans la liste.
	 *
	 * @return le nombre d'éléments
	 */
	public int size();

	/**
	 * Vérifie si la liste est vide.
	 *
	 * @return {@code true} si la liste est vide, {@code false} sinon
	 */
	public boolean isEmpty();

	/**
	 * Retourne l'élément à l'index spécifié dans la liste.
	 *
	 * @param index l'index de l'élément à retourner
	 * @return l'élément à l'index spécifié
	 * @throws IndexOutOfBoundsException si l'index est hors des limites de la liste
	 */
	public E get(int index);
}
