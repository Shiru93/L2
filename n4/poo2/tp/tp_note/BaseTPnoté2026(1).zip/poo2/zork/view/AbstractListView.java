/**
 * 
 */
package poo2.zork.view;

import java.util.Iterator;
import java.util.List;

/**
 * Fournit une structure de base pour afficher une liste d'éléments avec un
 * titre, un en-tête et un pied de page.
 *
 * @param <E> le type des éléments contenus dans la liste
 * 
 * @author Marc Champesme
 * @version 18 avril 2026
 */
abstract class AbstractListView<E> implements ListView<E> {

	/** Titre de la vue de liste. */
	private String title;

	/** Texte à afficher sous le titre (en-tête). */
	private String header;

	/** Liste des objets à afficher pour le choix. */
	private List<E> elements;

	/** Texte à afficher sous la liste (pied de page). */
	private String footer;

	/**
	 * Construit une nouvelle vue de liste à partir d'un builder.
	 *
	 * @param builder le builder contenant les informations nécessaires à la
	 *                construction de la vue
	 * @throws NullPointerException si le builder ou ses éléments sont {@code null}
	 */
	AbstractListView(GUIViewBuilder<E> builder) {
		if (builder == null) {
			throw new NullPointerException("Le builder ne peut pas être null.");
		}
		if (builder.elements == null) {
			throw new NullPointerException("La liste des éléments ne peut pas être null.");
		}
		elements = builder.elements;
		title = builder.title;
		header = builder.header;
		footer = builder.footer;
	}

	/**
	 * Retourne le titre de la vue de liste.
	 *
	 * @return le titre de la vue
	 */
	@Override
	public String getTitle() {
		return title;
	}

	/**
	 * Retourne le texte de l'en-tête de la vue de liste.
	 *
	 * @return le texte de l'en-tête
	 */
	@Override
	public String getHeaderText() {
		return header;
	}

	/**
	 * Retourne le texte du pied de page de la vue de liste.
	 *
	 * @return le texte du pied de page
	 */
	@Override
	public String getFooterText() {
		return footer;
	}

	/**
	 * Retourne un itérateur sur les éléments de la liste.
	 *
	 * @return un itérateur sur les éléments de la liste
	 */
	@Override
	public Iterator<E> iterator() {
		return elements.iterator();
	}

	/**
	 * Retourne le nombre d'éléments dans la liste.
	 *
	 * @return le nombre d'éléments
	 */
	@Override
	public int size() {
		return elements.size();
	}

	/**
	 * Vérifie si la liste est vide.
	 *
	 * @return {@code true} si la liste est vide, {@code false} sinon
	 */
	@Override
	public boolean isEmpty() {
		return elements.isEmpty();
	}

	/**
	 * Retourne l'élément à l'index spécifié dans la liste.
	 *
	 * @param index l'index de l'élément à retourner
	 * @return l'élément à l'index spécifié
	 * @throws IndexOutOfBoundsException si l'index est hors des limites de la liste
	 *                                   (c'est-à-dire si {@code index < 0} ou
	 *                                   {@code index >= size()})
	 */
	@Override
	public E get(int index) {
		return elements.get(index);
	}
}
