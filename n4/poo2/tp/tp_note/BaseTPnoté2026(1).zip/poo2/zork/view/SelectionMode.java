package poo2.zork.view;

/**
 * Mode de sélection pour une liste d'élements.
 * 
 * @author Marc Champesme
 * @version 23 avril 2026
 */
public enum SelectionMode {
	/**
	 * Aucun élément ne peut être sélectionné.
	 */
	NO_SELECTION,

	/**
	 * Seul un élément de la liste peut être sélectionné.
	 */
	SINGLE_SELECTION,

	/**
	 * Permet la sélection de plusieurs éléments de la liste.
	 */
	MULTIPLE_SELECTION
}
