package poo2.zork.view;

import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/**
 * Vue graphique pour afficher et interagir avec une liste d'éléments. Une
 * instance de cette classe peut-être créée à l'aide d'un ListViewBuilder obtenu
 * grâce à la méthode builder de l'interface ListView.
 * 
 * @param <E> le type des éléments de la liste
 * 
 * @author Marc Champesme
 * @version 18 avril 2026
 */
class GUIView<E> extends AbstractListView<E> implements ListSelectionListener {

	/** Fenêtre principale de l'interface graphique. */
	private JFrame myFrame;

	/** Panneau principal contenant les composants de l'interface. */
	private JPanel myPanel;

	/** Composant graphique représentant la liste des éléments. */
	private JList<E> list;

	/** Bouton d'exécution associé à la sélection d'un élément. */
	private JButton execButton;

	/**
	 * Construit une nouvelle vue graphique à partir d'un builder.
	 *
	 * @param builder le builder contenant les composants graphiques et les éléments
	 *                de la liste
	 * @throws NullPointerException si le builder ou l'un de ses composants est
	 *                              {@code null}
	 */
	GUIView(GUIViewBuilder<E> builder) {
		super(builder);
		if (builder == null || builder.theFrame == null || builder.myPanel == null || builder.list == null
				|| builder.execButton == null) {
			throw new NullPointerException("Le builder et ses composants ne peuvent pas être null.");
		}
		myFrame = builder.theFrame;
		myPanel = builder.myPanel;
		list = builder.list;
		execButton = builder.execButton;

		list.addListSelectionListener(this);
	}

	/**
	 * Méthode appelée lorsqu'un changement de sélection se produit dans la liste.
	 * Active ou désactive le bouton d'exécution en fonction de la sélection.
	 *
	 * @param e l'événement de sélection
	 */
	@Override
	public void valueChanged(ListSelectionEvent e) {
		if (e.getValueIsAdjusting() == false) {
			if (list.getSelectedIndex() == -1) {
				// Aucune sélection, désactiver le bouton.
				execButton.setEnabled(false);
			} else {
				// Sélection présente, activer le bouton.
				execButton.setEnabled(true);
			}
		}
	}

	/**
	 * Retourne l'élément actuellement sélectionné dans la liste.
	 *
	 * @return l'élément sélectionné, ou {@code null} si aucun élément n'est
	 *         sélectionné
	 */
	@Override
	public E getSelectedValue() {
		return list.getSelectedValue();
	}

	/**
	 * Retourne la liste des objets sélectionnés par l'utilisateur. Si le mode
	 * de sélection est SINGLE_SELECTION, la liste renvoyée contient l'unique éléments sélectionné.
	 * Si aucun élément n'est sélectionné renvoie une liste vide.
	 * 
	 * @return la liste des objets sélectionnés par l'utilisateur
	 */
	@Override
	public List<E> getSelectedValuesList() {
		// TODO A compléter
		return null;
	}

	/**
	 * Affiche la vue graphique. Définit le titre de la fenêtre, le panneau
	 * principal et rend la fenêtre visible.
	 */
	@Override
	public void showView() {
		myPanel.setOpaque(true); // Les panneaux de contenu doivent être opaques
		myFrame.setTitle(getTitle());
		myFrame.setContentPane(myPanel);

		// Afficher la fenêtre.
		myFrame.pack();
		myFrame.setVisible(true);
	}

	/**
	 * Affiche un message d'information à l'utilisateur.
	 *
	 * @param msg le message à afficher
	 * @throws NullPointerException si le message est {@code null}
	 */
	@Override
	public void showInfoMsg(String msg) {
		if (msg != null) {
			JOptionPane.showMessageDialog(myFrame, msg);
		} else {
			throw new NullPointerException("Le message ne peut pas être null.");
		}
	}

	/**
	 * Affiche un message de notification à l'utilisateur.
	 *
	 * @param msg le message à afficher
	 */
	@Override
	public void showNotificationMsg(String msg) {
		if (msg != null) {
			JOptionPane.showMessageDialog(myFrame, msg);
		} else {
			throw new NullPointerException("Le message ne peut pas être null.");
		}
	}

	/**
	 * Affiche un message d'alerte à l'utilisateur.
	 *
	 * @param msg le message à afficher
	 * @throws NullPointerException si le message est {@code null}
	 */
	@Override
	public void showAlertMsg(String msg) {
		if (msg != null) {
			JOptionPane.showMessageDialog(myFrame, msg, "Warning", JOptionPane.WARNING_MESSAGE);
		} else {
			throw new NullPointerException("Le message ne peut pas être null.");
		}
	}

	/**
	 * Affiche un message d'erreur à l'utilisateur.
	 *
	 * @param msg le message à afficher
	 * @throws NullPointerException si le message est {@code null}
	 */
	@Override
	public void showErrorMsg(String msg) {
		if (msg != null) {
			JOptionPane.showMessageDialog(myFrame, msg, "Error", JOptionPane.ERROR_MESSAGE);
		} else {
			throw new NullPointerException("Le message ne peut pas être null.");
		}
	}

}
