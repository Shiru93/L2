package poo2.zork.view;

import javax.swing.JFrame;
import java.awt.event.ActionListener;

/**
 * Builder pour construire une vue permettant d'affichier une liste d'éléments.
 * Permet de configurer un titre, un en-tête et un pied de page, et de choisir
 * un mode de sélection parmi les éléments de la liste. Si une fenêtre
 * principale et un ActionListener sont fournis, à l'aide de la méthode withGUI,
 * permet d'intégrer cette vue à une application avec interface graphique, dans
 * le cas contraire, la vue est purement textuelle pour un affichage dans le
 * terminal.
 *
 * @param <E> le type des éléments de la liste
 *
 * @author Marc Champesme
 * @version 23 avril 2026
 */
public interface ListViewBuilder<E> {

	/**
	 * Spécifie le mode de sélection appliqué à cette vue.
	 * 
	 * @param mode mode de sélection à appliquer
	 * 
	 * @return le builder courant pour permettre le chaînage des méthodes
	 * @throws NullPointerException si un des arguments spécifiés est {@code null}
	 */
	public ListViewBuilder<E> withSelectionMode(SelectionMode mode);

	/**
	 * Spécifie la fenêtre principale de l'application et l'écouteur d'action si la
	 * ListView doit s'inscrire dans une application avec interface graphique.
	 *
	 * @param frame    la fenêtre principale de l'application
	 * @param listener écouteur d'action qui exécute l'action souhaitée
	 * 
	 * @return le builder courant pour permettre le chaînage des méthodes
	 * @throws NullPointerException si un des arguments spécifiés est {@code null}
	 */
	public ListViewBuilder<E> withGUI(JFrame frame, ActionListener listener);

	/**
	 * Définit le titre de la vue de liste.
	 *
	 * @param s le titre à définir
	 * @return le builder courant pour permettre le chaînage des méthodes
	 * @throws NullPointerException si le titre {@code s} est {@code null}
	 */
	public ListViewBuilder<E> withTitle(String s);

	/**
	 * Définit le texte de l'en-tête de la vue de liste.
	 *
	 * @param s le texte de l'en-tête à définir
	 * @return le builder courant pour permettre le chaînage des méthodes
	 * @throws NullPointerException si le texte de l'en-tête {@code s} est
	 *                              {@code null}
	 */
	public ListViewBuilder<E> withHeaderText(String s);

	/**
	 * Définit le texte du pied de page de la vue de liste.
	 *
	 * @param s le texte du pied de page à définir
	 * @return le builder courant pour permettre le chaînage des méthodes
	 * @throws NullPointerException si le texte du pied de page {@code s} est
	 *                              {@code null}
	 */
	public ListViewBuilder<E> withFooterText(String s);

	/**
	 * Construit et retourne une nouvelle instance de {@link ListView} configurée
	 * avec les paramètres actuels du builder.
	 *
	 * @return une nouvelle instance de {@link ListView}
	 */
	public ListView<E> build();
}
