/**
 * 
 */
package poo2.zork;

import poo2.zork.controller.Game;
/**
 * 
 */
public class Zork {

	/**
	 * 
	 */
	private Zork() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Game zorkGame = new Game();
		zorkGame.showMenu();
	}

}
