package poo2.zork.view;

public class TextView {
	private String text;

	public TextView() {
	}

	public TextView(String s) {
		text = s;
	}

	public void setText(String s) {
		text = s;
	}

	public void show() {
		if (text != null) {
			System.out.println(text);
		} else {
			System.out.println();
		}
	}

}
