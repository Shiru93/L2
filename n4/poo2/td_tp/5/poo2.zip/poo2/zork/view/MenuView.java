/**
 * 
 */
package poo2.zork.view;

import java.io.Console;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * 
 */
class MenuView<E> implements ListView<E> {
	private String title;
	private String subTitle;
	private List<E> list;

	/**
	 * 
	 */
	public MenuView(String title, Iterable<? extends E> c) {
		if (title == null) {
			throw new NullPointerException();
		}
		this.title = title;
		list = new ArrayList<>();
		for (E elt : c) {
			if (elt == null) {
				throw new NullPointerException();
			}
			list.add(elt);
		}
	}

	@Override
	public Iterator<E> iterator() {
		return list.iterator();
	}

	@Override
	public void show() {
        System.out.print("\033[H\033[2J"); // Clear screen
        System.out.flush();
        System.out.println(title);
		if (isEmpty()) {
			showAlertMsg("Erreur: liste de choix vide");
			return;
		}
		if (subTitle != null) {
	        System.out.println(subTitle);			
	        System.out.println();			
		}
		int i = 0;
		for (E elt : this) {
			System.out.println("\t" + i + " : " + elt);
			i++;
		}

	}

	public boolean isEmpty() {
		return list.isEmpty();
	}

	public int size() {
		return list.size();
	}

	@Override
	public E readChoice() {
		Console cons = System.console();
		if (cons == null) {
			System.err.println("Erreur: console non disponible");
			return null;
		}
		int choice = -1;
		while (choice < 0 || choice >= size()) {
			System.out.print("Entrez le numéro de l'item choisit (" + "entre 0 et " + (list.size() - 1) + ") --> ");
			String line = cons.readLine();
			try {
				choice = Integer.parseInt(line);
			} catch (NumberFormatException e) {
				showAlertMsg("Erreur: vous devez entrer un chiffre entre 0 et " + (list.size() - 1));
				choice = -1;
			}
		}
		return list.get(choice);
	}

	@Override
	public void showNotificationMsg(String msg) {
		if (msg == null) {
			throw new NullPointerException();
		}
		System.out.println(msg);
		System.out.println("Tapez une touche pour continuer...");
		System.console().readLine();		
		
	}

	@Override
	public void showAlertMsg(String msg) {
		if (msg == null) {
			throw new NullPointerException();
		}
		System.out.println("Avertissement: " + msg);
		System.out.println("Tapez une touche pour continuer...");
		System.console().readLine();		
	}

	@Override
	public void showErrorMsg(String msg) {
		if (msg == null) {
			throw new NullPointerException();
		}
		System.err.println("Error:" + msg);
		System.out.println("Tapez une touche pour continuer...");
		System.console().readLine();		
	}

	@Override
	public void showInfoMsg(String msg) {
		if (msg == null) {
			throw new NullPointerException();
		}
		System.err.println(msg);		
	}

	@Override
	public void setSubTitle(String text) {
		subTitle = text;
	}

	@Override
	public void setTitle(String newTitle) {
		if (newTitle == null) {
			throw new NullPointerException();
		}
		title = newTitle;
	}
}
