/**
 * 
 */
package poo2.zork.view;

/**
 * Permet d'afficher une liste d'objets et de sélectionner un objet parmi
 * ceux-ci.
 * 
 * @param <E> le type des éléments affichés
 */
public interface ListView<E> extends Iterable<E> {

	/**
	 * Renvoie une ListView ayant le titre spécifié et permettant d'afficher les
	 * éléments de l'Iterable spécifié.
	 * 
	 * @param <T>   le type des éléments sélectionnables
	 * @param title le titre du menu
	 * @param c     les éléments parmi lesquels choisir
	 * 
	 * @return un menu ayant le titre spécifié pour choisir parmi les éléments
	 *         spécifiés
	 * 
	 * @throws NullPointerException si le titre ou l'Iterable sont null ou contient
	 *                              null
	 */
	public static <T> ListView<T> buildMenu(String title, Iterable<? extends T> c) {
		return new MenuView<>(title, c);
	}

	/**
	 * Remplace le titre affiché par la chaîne de caractères spécifiée.
	 * 
	 * @param newTitle le nouveau titre du menu
	 * 
	 * @throws NullPointerException si le titre spécifié est null
	 */
	public void setTitle(String newTitle);

	/**
	 * Remplace le sous-titre affiché en dessous du titre par la chaîne de
	 * caractères spécifiée. Si la valeur spécifiée est null, aucun sous-titre ne
	 * sera affiché.
	 * 
	 * @param text le nouveau sous-titre du menu
	 */
	public void setSubTitle(String text);

	/**
	 * Affiche le menu sous forme d'une liste numérotée.
	 */
	public void show();

	/**
	 * Affiche le message spécifié comme une information à l'utilisateur.
	 * 
	 * @param msg message d'information à afficher
	 */
	public void showInfoMsg(String msg);

	/**
	 * Affiche le message spécifié comme une information à l'utilisateur.
	 * 
	 * @param msg message d'information à afficher
	 */
	public void showNotificationMsg(String msg);

	/**
	 * Affiche le message spécifié comme une erreur de l'utilisateur.
	 * 
	 * @param msg message d'information à afficher
	 */
	public void showAlertMsg(String msg);

	/**
	 * Affiche le message spécifié comme une erreur indépendante de l'utilisateur.
	 * 
	 * @param msg message d'information à afficher
	 */
	public void showErrorMsg(String msg);

	/**
	 * Demande à l'utilisateur de choisir un objet parmi la liste d'objets affichés
	 * par la méthode show() et renvoie l'objet sélectionné.
	 * 
	 * @return l'objet choisi par l'utilisateur.
	 */
	public E readChoice();

}
