package poo2.zork.view;

import java.awt.BorderLayout;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTextArea;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;

public class GUIViewBuilder<E> extends AbstractListViewBuilder<GUIViewBuilder<E>, E> {
    private ActionListener listener;
    private Iterable<E> c;
    private boolean noSelect;
	JFrame myFrame;
	JPanel myPanel;
    JList<E> list;
    JButton execButton;

    
	public GUIViewBuilder(JFrame aFrame, ActionListener listener, Iterable<E> c) {
		super(c);
		this.c = c;
		myFrame = aFrame;
		this.listener = listener;
	}

	/**
	 * Pour créer une vue sans éléments
	 * à sélectionner. Dans une telle vue
	 * le bouton sera toujours actif.
	 */
	public GUIViewBuilder<E> withNoSelection() {
        noSelect = true;
		return this;
	}

	@Override
    GUIViewBuilder<E> self() {
		return this;
	}

	@Override
	public GUIView<E> build() {
		// Création d'un panel qui regroupe tous les éléments
		// de l'interface placé dans la JFrame
		myPanel = new JPanel(new BorderLayout());

		// Création d'une zone de texte au dessus de la liste des choix
		JTextArea headerText = new JTextArea(header, 3, 10);
        // Avec une marge autour de la zone
        headerText.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
        // Positionement du headerText en haut (nord) de la vue:
        myPanel.add(headerText,BorderLayout.NORTH);

        // Création du composant liste
		DefaultListModel<E> listModel = new DefaultListModel<>();
		for (E elt : c) {
			if (elt == null) {
				throw new NullPointerException();
			}
			listModel.addElement(elt);
		}
		list = new JList<>(listModel);
        list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        list.setVisibleRowCount(6);
        // Placement de la liste dans un scrollPanel:
        JScrollPane listScrollPane = new JScrollPane(list);
        listScrollPane.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
        // Placement de la liste au centre de la vue:
        myPanel.add(listScrollPane, BorderLayout.CENTER);



        // La zone du bas de la vue contient deux éléments:
        // - une zone de texte footerText
        // - et le bouton pour déclencher l'action
        // On doit les mettre ensemble dans un JPanel pour
        // pouvoir les placer ensemble en bas de la vue.
		JPanel footerPane = new JPanel();
        footerPane.setLayout(new BoxLayout(footerPane,
                                           BoxLayout.Y_AXIS));
        // Ajout d'une zone de texte en dessous de la liste
        JTextArea footerText = new JTextArea(footer, 3, 10);
        footerPane.add(footerText);

        // + un espacement vide
        footerPane.add(Box.createVerticalStrut(5));
        // + un trait horizontal
        footerPane.add(new JSeparator(SwingConstants.HORIZONTAL));
        // + un espacement vide
        footerPane.add(Box.createVerticalStrut(5));

        // Le bouton qui va déclencher l'action:
        execButton = new JButton("Ok"); // Label du bouton
		execButton.setActionCommand("Exec");
        execButton.addActionListener(listener);
        execButton.setEnabled(noSelect); // On attend la sélection
                                      // pour activer le bouton si
                                      // noSelect est false
        footerPane.add(execButton);
        // Ajout d'une marge tout autour du footerPanel:
        footerPane.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));

        // Placement du footerPanel en bas de la vue:
        myPanel.add(footerPane, BorderLayout.PAGE_END);	
        
		return new GUIView<>(this);
	}

}
