/**
 * 
 */
package poo2.zork.view;

/**
 * 
 */
public class MenuViewBuilder<E> extends AbstractListViewBuilder<MenuViewBuilder<E>, E> {

	public MenuViewBuilder(Iterable<E> c) {
		super(c);
	}

	@Override
	public MenuViewBuilder<E> self() {
		return this;
	}

	@Override
	public MenuView<E> build() {
		return new MenuView<>(this);
	}

}
