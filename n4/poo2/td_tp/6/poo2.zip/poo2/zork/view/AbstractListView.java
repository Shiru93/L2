/**
 * 
 */
package poo2.zork.view;

import java.util.Iterator;
import java.util.List;

/**
 * 
 */
public abstract class AbstractListView<E> implements ListView<E> {
	private String title; // le titre
	private String header; // texte a afficher sous le titre
	private List<E> elements; // Les objets a afficher pour le choix
	private String footer; // texte a afficher sous la liste
	
	AbstractListView(AbstractListViewBuilder<?, E> builder) {
		elements = builder.elements;
		title = builder.title;
		header = builder.header;
		footer = builder.footer;
	}
	
	@Override
	public String getTitle() {
		return title;
	}
	
	@Override
	public String getHeaderText() {
		return header;
	}
	
	@Override
	public String getFooterText() {
		return footer;
	}
	
	@Override
	public Iterator<E> iterator() {
		return elements.iterator();
	}
	
	@Override
	public int size() {
		return elements.size();
	}
	
	@Override
	public boolean isEmpty() {
		return elements.isEmpty();
	}
	
	@Override
	public E get(int index) {
		return elements.get(index);
	}
}
