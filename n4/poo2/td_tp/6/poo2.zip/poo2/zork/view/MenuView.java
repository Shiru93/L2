package poo2.zork.view;

import java.io.Console;

/**
 * 
 */
class MenuView<E> extends AbstractListView<E> {

	MenuView(MenuViewBuilder<E> builder) {
		super(builder);
	}

	@Override
	public void showView() {
		System.out.print("\033[H\033[2J"); // Clear screen
		System.out.flush();
		System.out.println(getTitle());
		if (isEmpty()) {
			showAlertMsg("Erreur: liste de choix vide");
			return;
		}
		System.out.println(getHeaderText());
		System.out.println();
		int i = 0;
		for (E elt : this) {
			System.out.println("\t" + i + " : " + elt);
			i++;
		}

	}

	@Override
	public E getSelectedValue() {
		Console cons = System.console();
		if (cons == null) {
			System.err.println("Erreur: console non disponible");
			return null;
		}
		int choice = -1;
		while (choice < 0 || choice >= size()) {
			System.out.print("Entrez le numéro de l'item choisit (" + "entre 0 et " + (size() - 1) + ") --> ");
			String line = cons.readLine();
			try {
				choice = Integer.parseInt(line);
			} catch (NumberFormatException e) {
				showAlertMsg("Erreur: vous devez entrer un chiffre entre 0 et " + (size() - 1));
				choice = -1;
			}
		}
		return get(choice);
	}

	@Override
	public void showNotificationMsg(String msg) {
		if (msg == null) {
			throw new NullPointerException();
		}
		System.out.println(msg);
		System.out.println("Tapez une touche pour continuer...");
		System.console().readLine();

	}

	@Override
	public void showAlertMsg(String msg) {
		if (msg == null) {
			throw new NullPointerException();
		}
		System.out.println("Avertissement: " + msg);
		System.out.println("Tapez une touche pour continuer...");
		System.console().readLine();
	}

	@Override
	public void showErrorMsg(String msg) {
		if (msg == null) {
			throw new NullPointerException();
		}
		System.err.println("Error:" + msg);
		System.out.println("Tapez une touche pour continuer...");
		System.console().readLine();
	}

	@Override
	public void showInfoMsg(String msg) {
		if (msg == null) {
			throw new NullPointerException();
		}
		System.err.println(msg);
	}
}
