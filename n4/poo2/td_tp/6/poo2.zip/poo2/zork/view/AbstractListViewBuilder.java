package poo2.zork.view;

import java.util.ArrayList;
import java.util.List;

public abstract class AbstractListViewBuilder<B extends AbstractListViewBuilder<B,E>, E> {
	String title = "    "; // le titre
	String header  = "    "; // texte a afficher sous le titre
	List<E> elements; // Les objets a afficher pour le choix
	String footer = "    "; // texte a afficher sous la liste
	
	public AbstractListViewBuilder(Iterable<E> c) {
		elements = new ArrayList<E>();
		for (E elt : c) {
			elements.add(elt);
		}
	}
	
	public B withTitle(String s) {
		title = s;
		return self();
	}
	
	public B withHeaderText(String s) {
		header = s;
		return self();
	}
	
	public B withFooterText(String s) {
		footer = s;
		return self();
	}

	// À redéfinier dans chaque sous-classe
	// par la ligne: return this;
	// Pour usage exclusif des sous-classes
	abstract B self();
	
	public abstract ListView<E> build();
}
