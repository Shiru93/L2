package poo2.zork.view;


/**
 * Permet d'afficher une liste d'objets et de sélectionner un objet parmi
 * ceux-ci.
 * 
 * @param <E> le type des éléments affichés
 */
public interface ListView<E> extends Iterable<E> {


	public String getTitle();

	public String getHeaderText();
	
	public String getFooterText();
	
	/**
	 * Affiche le menu sous forme d'une liste numérotée.
	 */
	public void showView();

	/**
	 * Affiche le message spécifié comme une information à l'utilisateur.
	 * 
	 * @param msg message d'information à afficher
	 */
	public void showInfoMsg(String msg);

	/**
	 * Affiche le message spécifié comme une information à l'utilisateur.
	 * 
	 * @param msg message d'information à afficher
	 */
	public void showNotificationMsg(String msg);

	/**
	 * Affiche le message spécifié comme une erreur de l'utilisateur.
	 * 
	 * @param msg message d'information à afficher
	 */
	public void showAlertMsg(String msg);

	/**
	 * Affiche le message spécifié comme une erreur indépendante de l'utilisateur.
	 * 
	 * @param msg message d'information à afficher
	 */
	public void showErrorMsg(String msg);

	/**
	 * Demande à l'utilisateur de choisir un objet parmi la liste d'objets affichés
	 * par la méthode show() et renvoie l'objet sélectionné.
	 * 
	 * @return l'objet choisi par l'utilisateur.
	 */
	public E getSelectedValue();
	
	public int size();
	
	public boolean isEmpty();
	
	public E get(int index);

}
