package poo2.zork.view;

import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class GUIView<E> extends AbstractListView<E> implements ListSelectionListener {
	private JFrame myFrame;
	private JPanel myPanel;
    private JList<E> list;
    private JButton execButton;


	GUIView(GUIViewBuilder<E> builder) {
		super(builder);
		myFrame = builder.myFrame;
		myPanel = builder.myPanel;
		list = builder.list;
		execButton = builder.execButton;
		
		list.addListSelectionListener(this);
	}
	
	/**
	 * Appelée par le composant liste à chaque fois que
	 * la sélection change dans la liste (i.e. quand
	 * l'utilisateur clique sur un item de la liste affichée).
	 */
	@Override
    public void valueChanged(ListSelectionEvent e) {
        if (e.getValueIsAdjusting() == false) {

            if (list.getSelectedIndex() == -1) {
            //No selection, disable fire button.
                execButton.setEnabled(false);

            } else {
            //Selection, enable the fire button.
                execButton.setEnabled(true);
            }
        }
    }

	@Override
    public E getSelectedValue() {
		return list.getSelectedValue();
    }

	@Override
	public void showView() {
        myPanel.setOpaque(true); //content panes must be opaque
		myFrame.setTitle(getTitle());
        myFrame.setContentPane(myPanel);

        //Display the window.
        myFrame.pack();
        myFrame.setVisible(true);
	}

	@Override
	public void showInfoMsg(String msg) {
		if (msg != null) {
            JOptionPane.showMessageDialog(myFrame, msg);
		}
	}

	@Override
	public void showNotificationMsg(String msg) {
		if (msg != null) {
            JOptionPane.showMessageDialog(myFrame, msg);
		}
	}

	@Override
	public void showAlertMsg(String msg) {
		if (msg != null) {
            JOptionPane.showMessageDialog(myFrame, msg, "Warning", JOptionPane.WARNING_MESSAGE);
		}
	}

	@Override
	public void showErrorMsg(String msg) {
		if (msg != null) {
            JOptionPane.showMessageDialog(myFrame, msg, "Error", JOptionPane.ERROR_MESSAGE);
		}
	}
}
