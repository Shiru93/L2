/**
 * 
 */
package poo2.zork.model;


import java.util.Collection;
import java.util.Iterator;

import poo2.zork.util.EnumCollection;
import poo2.zork.model.room.Room;
/**
 * 
 */
public abstract class ObjetZorkContainer extends EnumCollection<ObjetZork> {
	
	public ObjetZorkContainer() {
		super(ObjetZork.class);
	}

	public ObjetZorkContainer(Collection<ObjetZork> c) {
		super(ObjetZork.class, c);
		for (ObjetZork oz : c) {
			if (oz == null) {
				throw new NullPointerException();
			}
			if (!canAdd(oz)) {
				throw new IllegalStateException();
			}
		}
	}

	public abstract boolean canAdd(ObjetZork obj);

	@Override
	public boolean add(ObjetZork oz) {
		if (oz == null) {
			throw new NullPointerException();
		}
		if (!canAdd(oz)) {
			throw new IllegalStateException();
		}
		return super.add(oz);
	}


}
