/**
 * 
 */
package poo2.zork.controller;

import java.util.EnumMap;

import poo2.zork.model.Direction;
import poo2.zork.model.Location;
import poo2.zork.model.map.GameMap;
import poo2.zork.view.GUIView;
import poo2.zork.view.GUIViewBuilder;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JComponent;


/**
 * 
 */
public class GoCommand implements Command, ActionListener {
	private Game theGame;
	private GUIView<Direction> dirMenu;
	
	/**
	 * 
	 */
	public GoCommand(Game theGame) {
		this.theGame = theGame;
	}

	@Override
	public String getHelp() {
		return "Choix d'une direction pour aller à une des pièces voisines de cette pièce";
	}

	@Override
	public void execute() {
		// A completer
	}

	/**
	 * Appelée à chaque fois que l'utilisateur clique sur
	 * le bouton. Le paramètre ActionEvent est inutile
	 * ici, car un seul évenement est possible.
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		// A compléter
	}

	@Override
	public String toString() {
		return "Aller à";
	}

}
