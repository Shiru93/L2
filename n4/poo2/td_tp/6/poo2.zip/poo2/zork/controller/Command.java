/**
 * 
 */
package poo2.zork.controller;

/**
 * 
 */
public interface Command {
	public String getHelp();
	public void execute();
	public String toString();
}
