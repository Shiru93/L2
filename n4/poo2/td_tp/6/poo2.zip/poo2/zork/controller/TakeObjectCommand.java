/**
 * 
 */
package poo2.zork.controller;

import poo2.zork.model.Gamer;
import poo2.zork.model.ObjetZork;
import poo2.zork.model.room.Room;

import poo2.zork.view.GUIView;
import poo2.zork.view.GUIViewBuilder;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JComponent;
/**
 * 
 */
public class TakeObjectCommand implements Command, ActionListener {
	private Game theGame;
	private GUIView<ObjetZork> objMenu;
	private Room currentRoom;

	/**
	 * 
	 */
	public TakeObjectCommand(Game theGame) {
		this.theGame = theGame;
	}

	@Override
	public void execute() {
		// A completer
	}

	/**
	 * Appelée à chaque fois que l'utilisateur clique sur
	 * le bouton. Le paramètre ActionEvent est inutile
	 * ici, car un seul évenement est possible.
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		// A completer
	}

	@Override
	public String getHelp() {
		return "Il vous sera demandé de choisir l'objet à prendre dans la pièce courante";
	}

	@Override
	public String toString() {
		return "Prendre un objet dans la pièce courante";
	}

}
