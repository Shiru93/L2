/**
 * 
 */
package poo2.zork.controller;

import java.util.List;
import java.util.Optional;

import poo2.zork.model.Gamer;
import poo2.zork.model.Location;
import poo2.zork.model.map.GameMap;
import poo2.zork.model.map.RandomMapBuilder;
import poo2.zork.model.room.Room;
import static poo2.zork.model.ObjetZork.*;

import poo2.zork.view.GUIView;
import poo2.zork.view.GUIViewBuilder;
import javax.swing.JFrame;
import javax.swing.JComponent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * 
 */
public class Game implements ActionListener {
	private GameMap map;
	private Gamer theGamer;
	private Location currentLocation;
	private GUIView<Command> mainMenu;
	private JFrame theFrame;

	/**
	 * 
	 */
	public Game(JFrame frame) {
		theFrame = frame;
		map = new RandomMapBuilder()
				.withColNb(10)
				.withLineNb(10)
				.withRoomNb(40)
				.withNcopiesOfRoom("Amphi", "Description de l'amphi", 5)
				.withNcopiesOfRoom("Salle TD", "Description de la salle TD", 10)
				.withNcopiesOfRoom("Salle TP", "Description de la salle TP", 10)
				.withNcopiesOfRoom("Autre salle", "Description de la salle", 10)
				.build();
		theGamer = new Gamer("Jeanne", "The better gameuse of the universe");
		currentLocation = map.getEntranceLocation();
		Optional<Room> currentRoom = map.get(currentLocation);
		List<Command> lCmd = List.of(new GoCommand(this), new TakeObjectCommand(this),
							new DropObjectCommand(this),
							new GamerInventoryCommand(this), new RoomInventoryCommand(this),
							new QuitCommand(this));

		// A completer:
		// Création de la vue avec GUIViewBuilder:
		// mainMenu = new GUIViewBuilder<Command>(...)

	}

	public JFrame getFrame() {
		return theFrame;
	}
	public Gamer getGamer() {
		return theGamer;
	}

	public GameMap getMap() {
		return map;
	}
	public Location getCurrentLocation() {
		return this.currentLocation;
	}

	public void setCurrentLocation(Location loc) {
		this.currentLocation = loc;
	}

	public Room getCurrentRoom() {
		return map.get(currentLocation).get();
	}

	public void showMenu() {
		// A compléter
	}

	/**
	 * Appelée à chaque fois que l'utilisateur clique sur
	 * le bouton. Le paramètre ActionEvent est inutile
	 * ici, car un seul évenement est possible.
	 */
	public void actionPerformed(ActionEvent e) {
		// A compléter
	}

}
