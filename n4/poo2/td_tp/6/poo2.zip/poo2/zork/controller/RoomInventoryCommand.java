/**
 * 
 */
package poo2.zork.controller;

import poo2.zork.model.ObjetZork;
import poo2.zork.model.room.Room;
import poo2.zork.view.GUIView;
import poo2.zork.view.GUIViewBuilder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


/**
 * 
 */
public class RoomInventoryCommand implements Command, ActionListener {
	private Game theGame;

	/**
	 * 
	 */
	public RoomInventoryCommand(Game theGame) {
		this.theGame = theGame;
	}

	@Override
	public String getHelp() {
		return "Affiche les objets présents dans la pièce courante";
	}

	@Override
	public void execute() {
		// A completer
	}

	/**
	 * Appelée à chaque fois que l'utilisateur clique sur
	 * le bouton. Le paramètre ActionEvent est inutile
	 * ici, car un seul évenement est possible.
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		// A completer
	}

	@Override
	public String toString() {
		return "Inventaire de la pièce courante";
	}
}
