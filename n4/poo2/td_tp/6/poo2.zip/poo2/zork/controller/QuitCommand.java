/**
 * 
 */
package poo2.zork.controller;

import javax.swing.JOptionPane;

/**
 * 
 */
public class QuitCommand implements Command {
	private Game theGame;
	/**
	 * 
	 */
	public QuitCommand(Game theGame) {
		this.theGame = theGame;
	}

	@Override
	public String getHelp() {
		return "Pour quitter le jeu définitivement";
	}

	@Override
	public void execute() {
		JOptionPane.showMessageDialog(theGame.getFrame(), "Au revoir!");
		System.exit(0);
	}
	
	@Override
	public String toString() {
		return "Quitter";
	}

}
