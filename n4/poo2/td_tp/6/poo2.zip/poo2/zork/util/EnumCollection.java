package poo2.zork.util;

/**
 * 
 */

import java.util.AbstractCollection;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;

/**
 * Une implémentation spécialisée de Collection pour une utilisation avec les
 * types enum. Tous les éléments d'une EnumCollection doivent provenir d'un
 * unique type enum spécifié à la création de l'instance.
 * 
 * <p>
 * En interne EnumCollection utilise un tableau d'entiers contenant à chacune de
 * ses cases le nombre d'occurence d'une instance particulière du type enum et
 * un tableau contenant toutes les instances du type enum obtenu à l'aide d'un
 * appel à la méthode {@link Class#getEnumConstants()}.
 * </p>
 * 
 * @param E le type enum des éléments de cette collection
 * 
 * @invariant !contains(null);
 * @invariant (\forall E elt; contains(elt); elt.getClass() == elementType);
 * 
 * @author Marc Champesme
 * @version 23/11/2025
 */
public class EnumCollection<E extends Enum<E>> extends AbstractCollection<E> {
	private int[] content;
	private E[] allValues;
	private Class<E> elementType;

	/**
	 * Initialise une EnumCollection vide pouvant contenir des instances du type
	 * enum spécifié.
	 * 
	 * @param elementType le type enum des éléments de cette collection
	 * 
	 * @requires elementType != null;
	 * @ensures elementType() == elementType;
	 * @ensures isEmpty();
	 * 
	 * @throws NullPointerException si le type spécifié est null
	 */
	public EnumCollection(Class<E> elementType) {
		if (elementType == null) {
			throw new NullPointerException();
		}
		this.elementType = elementType;
		allValues = elementType.getEnumConstants();
		content = new int[allValues.length];
	}

	/**
	 * Initialise une EnumCollection pouvant contenir des instances du type enum
	 * spécifié et y ajoute les éléments de la collection spécifiée.
	 * 
	 * @param elementType le type enum des éléments de cette collection
	 * @param c           la collection dont les élements doivent être placés dans
	 *                    cette collection
	 * 
	 * @requires elementType != null && c != null && !c.contains(null);
	 * @ensures elementType() == elementType;
	 * @ensures hasSameContent(c);
	 * 
	 * @throws NullPointerException si le type ou la collection spécifié est null ou
	 *                              si la collection spécifiée contient null
	 */
	public EnumCollection(Class<E> elementType, Collection<E> c) {
		this(elementType);
		for (E elt : c) {
			if (elt == null) {
				throw new NullPointerException();
			}
			content[elt.ordinal()]++;
		}
	}

	/**
	 * Renvoie le type enum des éléments de cette Collection.
	 * 
	 * @return le type enum des éléments de cette Collection
	 * 
	 * @ensures \result != null;
	 * 
	 * @pure
	 */
	public Class<E> elementType() {
		return this.elementType;
	}

	/**
	 * Renvoie le nombre d'occurences de l'élément spécifié dans cette collection.
	 * 
	 * @param obj l'élément dont on souhaite connaitre le nombre d'occurences
	 * 
	 * @return le nombre d'occurences de l'élément spécifié dans cette collection
	 * 
	 * @ensures \result >= 0;
	 * @ensures (obj == null || obj.getClass() != elementType()) ==> \result == 0;
	 * @ensures \result > 0 <==> contains(obj);
	 * 
	 * @pure
	 */
	public int frequencyOf(Object obj) {
		if (!(obj instanceof Enum<?>)) {
			// ou bien if (obj == null || obj.getClass() != elementType())
			// ou bien if (!elementType.isInstance(obj)) 
			// mais if !(obj instanceof elementType) n'est pas autorisé
			// de même if !(obj instanceof E) n'est pas autorisé
			return 0;
		}
		Enum<?> elt = (Enum<?>) obj;
		return content[elt.ordinal()];
	}

	/**
	 * Ajoute l'élément spécifié à cette collection.
	 * 
	 * @param elt l'élément à ajouter
	 * 
	 * @return true
	 * 
	 * @requires elt != null;
	 * @ensures \result;
	 * @ensures contains(elt);
	 * @ensures size() == \old(size()) + 1;
	 * 
	 * @throws NullPointerException     si l'élément spécifié est null
	 */
	@Override
	public boolean add(E elt) {
		if (elt == null) {
			throw new NullPointerException();
		}
		content[elt.ordinal()]++;
		return true;
	}

	/**
	 * Ajoute n occurences de l'élément spécifié à cette collection.
	 * 
	 * @param n   nombre d'occurence de l'élément à ajouter
	 * @param elt l'élément à ajouter
	 * 
	 * @return le nombre d'occurences de l'objet spécifié après exécution
	 * 
	 * @requires elt != null;
	 * @requires n >= 0;
	 * @ensures \result == frequencyOf(elt);
	 * @ensures frequencyOf(elt) == \old(frequencyOf(elt)) + n;
	 * @ensures size() == \old(size()) + n;
	 * 
	 * @throws NullPointerException     si l'élément spécifié est null
	 * @throws IllegalArgumentException si le nombre d'occurences spécifié est
	 *                                  strictement négatif
	 */
	public int addN(int n, E elt) {
		if (elt == null) {
			throw new NullPointerException();
		}
		if (n < 0) {
			throw new IllegalArgumentException();
		}
		content[elt.ordinal()] += n;
		return content[elt.ordinal()];
	}

	/**
	 * Retire une occurence de l'élément spécifié de cette collection.
	 * 
	 * @param elt l'élément à retirer
	 * 
	 * @return true si l'exécution a modifié cette collection; false sinon
	 * 
	 * @ensures \result <==> \old(contains(obj));
	 * @ensures \result <==> frequencyOf(obj) == \old(frequencyOf(obj)) - 1;
	 */
	@Override
	public boolean remove(Object obj) {
		if (!(obj instanceof Enum<?>)) {
			return false;
		}
		Enum<?> elt = (Enum<?>) obj;
		if (content[elt.ordinal()] == 0) {
			return false;
		}
		content[elt.ordinal()]--;
		return true;
	}

	/**
	 * Renvoie true si l'objet spécifié est présent dans cette collection.
	 * 
	 * @param obj l'objet dont on souhaite tester l'appartenance à cette collection
	 * 
	 * @return true si l'objet spécifié est présent dans cette collection; false
	 *         sinon
	 * 
	 * @ensures \result <==> frequencyOf(obj) > 0;
	 * 
	 * @pure
	 */
	@Override
	public boolean contains(Object obj) {
		if (!(obj instanceof Enum<?>)) {
			return false;
		}
		Enum<?> elt = (Enum<?>) obj;
		return content[elt.ordinal()] > 0;
	}

	/**
	 * Renvoie un itérateur sur les éléments de cette collection. Cet itérateur
	 * permet la suppresion d'éléments de cette collection à l'aide de sa méthode
	 * remove().
	 * 
	 * @return un itérateur sur les éléments de cette collection
	 * 
	 * @ensures \result != null;
	 * 
	 * @pure
	 */
	@Override
	public Iterator<E> iterator() {
		return new EnumCollectionIterator<E>(this, allValues, content);
	}

	/**
	 * Renvoie le nombre d'éléments présents dans cette collection.
	 * 
	 * @return le nombre d'éléments présents dans cette collection
	 * 
	 * @ensures \result == (\sum E elt; contains(elt); frequencyOf(elt));
	 * 
	 * @pure
	 */
	@Override
	public int size() {
		int count = 0;
		for (int i : content) {
			count += i;
		}
		return count;
	}

	/**
	 * Renvoie true si et seulement si la collection spécifiée contient les mêmes
	 * éléments que cette collection.
	 * 
	 * @implSpec si la collection spécifiée est une EnumCollection applique un
	 *           algorithme plus efficace tirant partie de son implémentation
	 *           spécifique en évitant de faire une itération sur l'ensemble
	 *           des éléments.
	 * 
	 * 
	 * @param c la collection à comparer à cette collection
	 * 
	 * @return true si et seulement si la collection spécifiée contient les mêmes
	 *         éléments que cette collection
	 * 
	 * @ensures \result <==> c != null && (\forall E elt; contains(elt);
	 *          frequencyOf(elt) == Collections.frequency(c, elt));
	 * 
	 * @pure
	 */
	public boolean hasSameContent(Collection<?> c) {
		if (c == null) {
			return false;
		}
		if (this == c) {
			return true;
		}
		if (size() != c.size()) {
			return false;
		}
		if (c instanceof EnumCollection<?>) {
			EnumCollection<?> ec = (EnumCollection<?>) c;
			if (ec.elementType() == this.elementType) {
				for (int i = 0; i < content.length; i++) {
					if (content[i] != ec.content[i]) {
						return false;
					}
				}
				return true;
			}
			return false;
		}
		LinkedList<?> list = new LinkedList<>(c);
		for (E elt : this) {
			if (!list.remove(elt)) {
				return false;
			}
		}
		return true;
	}
}
