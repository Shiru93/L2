/**
 * 
 */
package poo2.zork;

import javax.swing.JFrame;

import poo2.zork.controller.Game;

/**
 * 
 */
public class Zork {
	private Zork() {
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		JFrame theFrame = new JFrame("ZorkDemo");
        theFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        theFrame.setLocation(500,400);

		Game zorkGame = new Game(theFrame);

		javax.swing.SwingUtilities.invokeLater(zorkGame::showMenu);
	}

}
