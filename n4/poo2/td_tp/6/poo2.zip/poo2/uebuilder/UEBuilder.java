package poo2.uebuilder;


public class UEBuilder {
    String name;
    String description;
    int ects = 4;
    int coefP1 = 1;
    int coefP2 = 2;
    int coefTP = 1;
    int numSemestre = 1;

    public UEBuilder(String name, String description) {
        if (name == null || description == null) {
            throw new NullPointerException();
        }
        this.name = name;
        this.description = description;
    }

    public UEBuilder withEcts(int val) {
        ects = val;
        return this;
    }

    public UEBuilder withCoefP1(int val) {
        coefP1 = val;
        return this;
    }

    public UEBuilder withCoefP2(int val) {
        coefP2 = val;
        return this;
    }
    public UEBuilder withCoefTP(int val) {
        coefP2 = val;
        return this;
    }
    public UEBuilder withNumSemestre(int val) {
        coefP2 = val;
        return this;
    }

    public UniteEnseignement build() {
        return new UniteEnseignement(this);
    }

}
