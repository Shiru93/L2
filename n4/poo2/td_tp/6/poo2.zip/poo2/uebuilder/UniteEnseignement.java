package poo2.uebuilder;

public class UniteEnseignement {
    private String name;
    private String description;
    private int ects = 4;
    private int coefP1 = 1;
    private int coefP2 = 2;
    private int coefTP = 1;
    private int numSemestre = 1;

    public UniteEnseignement(String name, String description, int ects, int coefP1, int coefP2, int coefTP, int numSemestre) {

    }

    UniteEnseignement(UEBuilder builder) {
        name = builder.name;
        description = builder.description;
        ects = builder.ects;
        coefP1 = builder.coefP1;
        coefP2 = builder.coefP2;
        coefTP = builder.coefTP;
        numSemestre = builder.numSemestre;
    }

}
