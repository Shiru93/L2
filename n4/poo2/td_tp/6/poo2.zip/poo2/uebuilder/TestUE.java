package poo2.uebuilder;

public class TestUE {
    public static void main(String[] args) {
        // Constructeur a parametres multiples, source de confusion
        UniteEnseignement poo2 = new UniteEnseignement("POO2",
                                            "Design Patterns",
                                            4, 1, 2, 1, 2);
        // Avec builder, c'est plus clair !
        poo2 = new UEBuilder("POO2","Design Patterns")
                                        .withEcts(4)
                                        .withCoefTP(1)
                                        .withCoefP1(1)
                                        .withCoefP2(2)
                                        .withNumSemestre(4)
                                        .build();
    }
}
