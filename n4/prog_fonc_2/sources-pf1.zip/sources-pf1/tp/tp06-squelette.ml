(** Exemples tirés du CM **)

(* pour ne pas avoir à préfixer tout le temps *)
open List;;

(* type enregistrement *)
type personne =
  {
    nom : string;
    age : int;
  };;

let lPers = [ {nom = "Toto"; age = 12 } ; {nom = "Marcel"; age = 28} ; {
              nom = "Georgette"; age = 24}  ];;

(* map f l applique la fonction f à chaque élément de l *)
(* age des personnes de la liste *)
let lAges = map  (fun x -> x.age) lPers;;

(* filter f l garde les éléments x de l pour lesquels f x est vrai *)
(* sélectionne les ages >= 18 *)
let res = filter (fun x -> x >= 18) lAges;;

(*noms des personnes majeures de la liste *)
map (fun p -> p.nom) (filter (fun p -> p.age >= 18) lPers);;

(** Fin des exemples tirés du CM **)



(* Exercice 1 *)

type livre =
  {
    titre : string ;
    auteur : string ;
    nbEmprunts : int ;
  };;







(* Exercice 2 *)




(* Exercice 3 *)


type ('a, 'b) dict = ('a * 'b) list ;; (* dictionnaire avec cles de type ’a et valeurs de type ’b *)
