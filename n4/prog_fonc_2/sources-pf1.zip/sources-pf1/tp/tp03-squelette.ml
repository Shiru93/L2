(** Exemples tirés du CM **)
type point = int * int;;

let estOrigine (p:point) =
  let (x, y) = p in (x = 0) && (y = 0);;

type jour =
  | Lun | Mar | Mer | Jeu | Ven | Sam | Dim

let string_of_jour j =
  match j with
  | Lun -> "lundi"
  | Mar -> "mardi"
  | Mer -> "mercredi"
  | Jeu -> "jeudi"
  | Ven -> "vendredi"
  | Sam -> "samedi"
  | Dim -> "dimanche";;

(* _ : joker : les cas restants *)
let enWeekend j =
  match j with
  | Sam | Dim -> true
  | _ -> false;;

(* type énuméré utilisant des données *)
type figure =
  | Ellipse of point * int * int
  | Rectangle of point * int * int;; 

(* Ellipse de centre (12, 3), de rayons 10 et 5*)
let e1 = Ellipse((12, 3), 10, 5);;
(* carré dont le coin est à l'origine *)
let carre = Rectangle((0, 0), 3, 3);;

(* dilate la figure par le coefficient c *)
let dilate f c =
  match f with
  | Ellipse (p, gr, pr) -> Ellipse (p, gr*c, pr*c)
  | Rectangle (p, long, larg) -> Rectangle (p, long*c, larg*c);;

let estCarre f =
  match f with
  | Rectangle (_, long, larg) when long = larg -> true
  | _ -> false;;

let estSurXEgalY f =
  match f with
  | Rectangle ((x, y), _, _) -> x=y
  | Ellipse ((x, y), _, _)   -> x=y;;


(** fin des exemples tirés du CM **)


type couleur =
  | Trefle
  | Carreau
  | Coeur
  | Pique;;

type valeur = (* à compléter *);;

type carte =
   | Card of valeur * couleur;;

