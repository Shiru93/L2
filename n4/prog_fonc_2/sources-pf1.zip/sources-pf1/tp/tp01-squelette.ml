(* Exercice 1*)

12;;
12+3;;
string_of_int 12;;
true;;
"true";;
"coucou"^" salut";;
true || 2 = 3;;
(if true then 12 else 23)+1;;
12 > 24;;
let x = 12 in x+1;;
let x = "coucou " in x^" salut";;

(*Exercice 2*)

let pi = 3.14 in pi + 3;;
if (22 = 3) then "coucou" else 23;;
(let x = 3) + 5;;
false && 3;;
let i = 22 in "coucou "^i;;

(*Exercice 3*)

"Hello world!";;
print_string "Hello world!";;
print_endline "Hello world!";;

(*Exercice 4*)

let incr (x:float):float = x+1;;
let concat (n:int):int = "coucou"^(string_of_int n);;
let estMajeur (age:int):bool =
  if (age >= 18) then "majeur"
  else "mineur";;
let estMajeurPoli (age:int):string =
  (print_string "Bonjour";
   (age >= 18));;

(*Exercice 5*)
