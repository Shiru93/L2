(* Exercice 1 *)

type 'a pile =
  | PVide
  | Empiler of 'a * 'a pile;;


(*rappel de la fonction "hauteur" vue en CM *)
let rec hauteur p =
  match s with
  | PVide -> 0
  | Empiler (_, p') -> 1 + hauteur p';;



(* Exercice 2*)

type exprBool =
  | Vrai
  | Faux
  | Non of exprBool
  | Et of exprBool * exprBool
  | Ou of exprBool * exprBool
  | Impl of exprBool * exprBool;;


let rec effacerNeg b = failwith "pas implémenté";;

(* Neg(V /\ F) = F \/ V *)
assert(effacerNeg(Non (Et (Vrai, Faux))) = Ou (Faux, Vrai));;
(* Neg(V => F) = V /\ V *)
assert(effacerNeg(Non (Impl (Vrai, Faux))) = Et (Vrai, Vrai));;
(*V => Neg(F) = V => V*)
assert(effacerNeg(Impl (Vrai, Non(Faux)))=Impl (Vrai, Vrai));;
(*Neg(Neg (V /\ Neg(F))) = V /\ V *)
assert(effacerNeg(Non (Non (Et (Vrai, Non(Faux)))))=Et (Vrai, Vrai));;
(* V /\ F = V /\ F *)
assert(effacerNeg (Et (Vrai, Faux)) = Et (Vrai, Faux));;

let rec distribuer b = failwith "pas implémenté";;

(* (V \/ V) /\ F = (V /\ F) \/ (V /\ F) *)
assert(distribuer(Et(Ou(Vrai, Vrai), Faux)) = Ou (Et (Vrai, Faux), Et (Vrai, Faux)));;
(* F /\ (V \/ V)  = (F /\ V) \/ (F /\ V) *)
assert(distribuer(Et(Faux, Ou(Vrai, Vrai))) = Ou (Et (Faux, Vrai), Et (Faux, Vrai)));;
(* F => ((V \/ V) /\ F) = F => ((V /\ F) \/ (V /\ F)) *)
assert(distribuer(Impl(Faux, Et(Ou(Vrai, Vrai), Faux)))
       = Impl (Faux, Ou (Et (Vrai, Faux), Et (Vrai, Faux))));;
(* F \/ ((V \/ V) /\ F) = F \/ ((V /\ F) \/ (V /\ F)) *)
assert(distribuer(Ou(Faux, Et(Ou(Vrai, Vrai), Faux)))
       = Ou (Faux, Ou (Et (Vrai, Faux), Et (Vrai, Faux))));;
(* not ((V \/ V) /\ F) = not ((V /\ F) \/ (V /\ F)) *)
assert(distribuer(Non(Et(Ou(Vrai, Vrai), Faux)))
       = Non (Ou (Et (Vrai, Faux), Et (Vrai, Faux))));;
(* (V \/ V) /\ (F \/ F) = ((V /\ F) \/ (V /\ F)) \/ (V /\ F) \/ (V /\ F) *)
assert(distribuer(Et(Ou(Vrai, Vrai), Ou(Faux, Faux)))
       = Ou (Ou (Et (Vrai, Faux), Et (Vrai, Faux)),
             Ou (Et (Vrai, Faux), Et (Vrai, Faux))));;
(* ((V \/ V) \/ V) /\ F = ((V /\ F) \/ (V /\ F)) \/ (V/\F)  *)
assert(distribuer(Et(Ou(Ou(Vrai, Vrai), Vrai), Faux))
       = Ou (Ou (Et (Vrai, Faux), Et (Vrai, Faux)), Et (Vrai,
                                                        Faux)));;
(* ((V \/ V) /\ F) /\ F = ((V /\ F) /\ F) \/ ((V /\ F) /\ F)   *)
assert(distribuer(Et (Et(Ou(Vrai, Vrai), Faux), Faux))
       = Ou (Et (Et (Vrai, Faux), Faux), Et (Et (Vrai, Faux), Faux)));;

