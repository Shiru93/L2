(** Exemples tirés du CM **)

type 'a abin =
  | ETree
  | Node of 'a * 'a abin *'a abin;;

let tc = Node('C', ETree, ETree);;
let tabc = Node('A', Node('B', ETree, ETree),
                Node('C', ETree, ETree));;
let tbla = Node('B', Node('L', Node('A', ETree, ETree), ETree), ETree);;

let rec nbf t =
  match t with
  | ETree -> 0
  | Node(_, ETree, ETree) -> 1
  | Node(_, t1, t2) -> (nbf t1) + nbf t2;;

let rec haut t =
  match t with
  | ETree -> 0
  | Node(_, t1, t2) -> (max (haut t1) (haut t2))-1;;

(** Fin des exemples **)




(** Exercice 1 **)

type 'a aBin =
| Etree
| Noeud of 'a * 'a aBin * 'a aBin ;;





(** Exercice 2 **)

type 'a anr =
| EAnr
| Noeudnr of 'a * 'a forest
and 'a forest =
| Eforest
| Fcons of 'a anr * 'a forest;;



(* Question 3 *)

type 'a anr =
| EAnr
| Noeudnr of 'a * ('a anr) list ;;



(** Exercice 3 **)

type op = Plus | Mult | Minus | Div ;;
type eArith =
| Num of int
| Eop of op * eArith * eArith ;;




(** Exercice 4 **)

type abrint =
| Eabr
| Noeudabr of int * abrint * abrint ;;
