(** Exemples issus du cours **)

(* Exemple simple: somme de 1 à n *)
let rec somme n = 
  if (n=1) then 1 else n + somme (n-1);;

(* Boucle : afficher la table de multiplication de nb *)

let tableMult nb =
  let rec tableAux i = 
    if (i<=9) then 
      (print_int (i*nb);
       print_newline ();
       tableAux (i+1))
  in tableAux 1;;

(* Boucles imbriquées *)
let triangle n =
  let rec ligne j k =
    if (j <= k) then
      (print_string("*"); ligne (j+1) k)
  in
  let rec triangleAux i = 
    if (i <= n) then
      (ligne 1 i; print_newline (); triangleAux (i+1))
  in triangleAux 1;;

(* Fonctions mutuellement récursives *)
let rec pair n =
  if (n = 0) then true
  else (impair (n-1))
and impair n =
  if (n = 0) then false
  else (pair (n-1));;


(** Fin des exemples du cours **)



(** Exemples d'utilisation des fonctions sur les chaînes pour *)
(** l'exercice 3 **)
let s = "coucou";;
s.[0];;
s.[1];;
"toto".[2];;
String.length s;;
String.sub s 0 3;;
String.sub s 1 4;;
