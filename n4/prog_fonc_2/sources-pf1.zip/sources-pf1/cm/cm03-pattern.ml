(** alias, couple *)
type point = int * int;;

let p1 = (12, 28);;
let (p2:point) = (24, 42);;

(* décomposition avec le let *)
let estOrigine (p:point) =
  let (x, y) = p in (x = 0) && (y = 0);;
estOrigine p1;;
estOrigine (0, 0);;
estOrigine 0;;

(* les éléments ne sont pas forcément du même type *)
("coucou", 24);;
(* on peut faire des n-uplets de taille (presque) quelconque*)
("coucou", 23, 'c', 12, 3.2);;

(*W*)
(* Quel seront les résultats des calculs suivants ?*)
let (x, y, z, t, u) = ("salut", 3, "coucou", 28, 2.4) in t-y;;
let (x, y, z, t) = ("yo", "wesh", 12, 3.14, 8) in x^y;;


(** type énuméré *)
type jour =
  | Lun | Mar | Mer | Jeu | Ven | Sam | Dim

let j1 = Lun;;

(* analyse de cas: filtrage de motif, pattern matching en anglais *)
let string_of_jour j =
  match j with
  | Lun -> "lundi"
  | Mar -> "mardi"
  | Mer -> "mercredi"
  | Jeu -> "jeudi"
  | Ven -> "vendredi"
  | Sam -> "samedi"
  | Dim -> "dimanche";;

string_of_jour Lun;;
(* si le filtrage n'est pas exhaustif, on a un avertissement, pas une 
  erreur*)
let string_of_jour j =
  match j with
  | Lun -> "lundi"
  | Mar -> "mardi"
  | Mer -> "mercredi"
  | Jeu -> "jeudi"
  | Ven -> "vendredi"
  | Sam -> "samedi";;

(* mais on a une erreur si on essaye un cas pas pris en compte *)
string_of_jour Dim;;


(* comme pour les "if", toutes les branches doivent renvoyer le même *)
(* type*)
let string_of_jour j =
  match j with
  | Lun -> "lundi"
  | Mar -> "mardi"
  | Mer -> "mercredi"
  | Jeu -> "jeudi"
  | Ven -> "vendredi"
  | Sam -> "samedi"
  | Dim -> 0;;

(* renvoie vrai si on est en week-end*)
let enWeekend j =
  match j with
  | Lun -> false
  | Mar -> false
  | Mer -> false
  | Jeu -> false
  | Ven -> false
  | Sam -> true
  | Dim -> true;;

enWeekend Lun;;
enWeekend Dim;;

let enWeekend j =
  match j with
  | Lun | Mar | Mer | Jeu | Ven -> false
  | Sam | Dim -> true;;

(* _ : joker : les cas restants *)
let enWeekend j =
  match j with
  | Sam | Dim -> true
  | _ -> false;;

let enWeekend j = (j = Sam) || (j = Dim);;




(** type énuméré utilisant des données *)
type figure =
  (* Ellipse permet de construire une figure avec 3 données*)
  (* centre, grand rayon, petit rayon *)
  | Ellipse of point * int * int
  (* Rectangle permet de construire une figure avec 3 données*)
  (* coin inférieur gauche, longueur, largeur *)
  | Rectangle of point * int * int;; 

(* Ellipse de centre (12, 3), de rayons 10 et 5*)
let e1 = Ellipse((12, 3), 10, 5);;
(* carré dont le coin est à l'origine *)
let carre = Rectangle((0, 0), 3, 3);;
p1;;
let e2 = Ellipse(p1, 28, 3);;


(* dilate la figure par le coefficient c *)
let dilate f c =
  match f with
  (* on liste tous les cas possibles *)
  | Ellipse (p, gr, pr) -> Ellipse (p, gr*c, pr*c)
  (* dans chaque cas, on donne des noms aux données stockées dans chaque figure*)
  (* pour les réutiliser dans le corps du "match" *)
  (* ici, p est le centre, gr le grand rayon, pr le petit rayon*)
  | Rectangle (p, long, larg) -> Rectangle (p, long*c, larg*c);;
  (*p est le coin, long la longueur, larg la largeur*)

dilate e1 2;;
dilate carre 2;;
dilate e2 2;;

(*remarque: dilate f c ne modifie pas la figure f, mais en construit *)
(*une nouvelle (immuabilité des données) *)

(* on ne peut plus utiliser une conditionnelle*)
let estEllipse f = (f = Ellipse);;

(* il faut utiliser un filtrage *)
let estEllipse f =
  match f with
  | Ellipse (p, gr, pr) -> true
  | Rectangle (p, long, larg) -> false;;

estEllipse e1;;
estEllipse carre;;

(* on peut simplifier avec le joker pour les arguments inutiles *)
let estEllipse f =
  match f with
  | Ellipse (_, _, _) -> true
  | Rectangle (_, _, _) -> false;;

let estEllipse f =
  match f with
  | Ellipse (_, _, _) -> true
  | _ -> false;;


let pi = 3.14;;

let surface f =
  match f with
  | Ellipse (p, gr, pr) -> pi *. float_of_int (gr*pr)
  | Rectangle (p, long, larg) -> float_of_int (long*larg);;

surface e1;;
surface carre;;
surface e2;;

let surface f =
  match f with
  | Ellipse (_, gr, pr) -> pi *. float_of_int (gr*pr)
  | Rectangle (_, long, larg) -> float_of_int (long*larg);;

(* W *)
(* quel est le résultat de
   toto (Rectangle ((10, 2), 12, 3)) ?
*)
let toto f =
  match f with
  | Ellipse (p, gr, pr) -> Rectangle (p, pr, pr)
  | Rectangle (p, long, larg) -> Ellipse (p, long, long);;


(* renvoie vrai si la figure est un carré*)
let estCarre f =
  match f with
  | Rectangle (_, long, larg) -> (long = larg)
  | _ -> false;;

estCarre e1;;
estCarre carre;;

(* on ne peut pas réutiliser plusieurs fois le même nom dans un motif*)
let estCarre f =
  match f with
  | Rectangle (_, l, l) -> true
  | _ -> false;;

(* mais on peut écrire des conditions avec "when" *)
let estCarre f =
  match f with
  | Rectangle (_, long, larg) when long = larg -> true
  | _ -> false;;

(* comme (presque) tout en caml, le filtrage est une expression*)
(* renvoie vrai si le point de la figure est sur la ligne x=y*)
let estSurXEgalY f =
  let p =
    match f with
    | Rectangle (pt, _, _) -> pt
    | Ellipse (pt, _, _) -> pt
  in let (x, y) = p in (x=y);;

estSurXEgalY (Ellipse ((12, 12), 20, 3));;
estSurXEgalY (Rectangle ((23, 5), 20, 3));;

let estSurXEgalY f =
  let (x, y) =
    match f with
    | Rectangle (pt, _, _) -> pt
    | Ellipse (pt, _, _) -> pt
  in (x=y);;

(* on peut faire des motifs imbriqués *)
let estSurXEgalY f =
  match f with
  | Rectangle ((x, y), _, _) -> x=y
  | Ellipse ((x, y), _, _)   -> x=y;;


(* les motifs sont testés dans l'ordre *)

let aLOrigine f =
  match f with
  | Rectangle ((0, 0), _, _) -> true
  | Rectangle (_, _, _)      -> false
  | Ellipse ((0, 0), _, _)   -> true
  | Ellipse (_, _, _)        -> false;;

aLOrigine (Rectangle ((0, 0), 20, 3));;
aLOrigine (Rectangle ((3, 5), 20, 3));;


(* W *)
(* quel est le résultat de
   toto (Rectangle ((10, 2), 12, 3)) ?
*)
let toto f =
  match f with
  | Rectangle (_, long, larg) when long > larg -> long
  | Rectangle (_, _, larg) -> larg
  | Ellipse (_, gr, pr) when gr > pr -> gr
  | Ellipse (_, _, pr) -> pr;;


(* quels sont les types des jokers dans la fonction toto ? *)

(* comment simplifier la fonction suivante? *)
let estCercleOuCarre f =
  match f with
  | Rectangle (p, long, larg) when long = larg -> true
  | Rectangle (p, long, larg) -> false
  | Ellipse (p, gr, pr) when gr = pr -> true
  | Ellipse (p, gr, pr) -> false;;
