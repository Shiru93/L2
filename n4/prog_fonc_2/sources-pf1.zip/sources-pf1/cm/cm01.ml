(** ctrl+c ctrl+e pour lancer le mode interactif
    ctrl+x ctrl+e pour envoyer du code à l'interprète *)

(** Types de base *)

2;;
"coucou";;
1.2;;
'c';;
1+1;;


(**Caml est "fortement typé" *)
1 + 1.5;;
1 +. 1.5;;
1. +. 1.5;;
(float_of_int 1) +. 1.5;;

(** booléens et conditionnelle *)
true;;
false;;
12 > 3;;
(12 > 3) || ("coucou" = "salut");; (* test d'égalité : un seul '=' *)
(12 > 3) && ("coucou" != "salut");;
not (12 > 3);;
if 12 > 3 then "coucou" else "salut";;
if 12 > 3 then "coucou";; (* branche else obligatoire *)
if 12 < 3 then "coucou" else
  if 12 > 3 then "salut" else "wesh";;
(*if then else est une expression *)
(if 12 > 3 then "coucou" else "salut")^" wesh";;
(** W **)

(**Nommer des valeurs *)
let x = 2;;
x+12;;
let y = x+2;;
let x = 2 in x*x;;

(**Difference entre let ... et let ... in *)
let x = 2;; (*instruction, ne retourne pas de résultat *)
let x = 2 in x;; (*expression, retourne un résultat *)
(let x = 2) + 3;;
(let x = 2 in x) + 3;;
let x = 2;;
let x = x+1;;

(**portee des nommages *)
let y = 2 in
    let x = 3 in x+y;;
let x = 2 in
    (let x = 2 in x)+x;;
let x = 2 in
    (let z = 2 in z)+x;;
let x = (let x = 3 in x) in x+1;;
let x = (let y = 3 in y) in x+1;;

(**W**)

(**fonctions*)

let incr (x:int):int = x+1;;
let incr x = x+1;;
incr 2;;
incr (2*2);;
incr 2*2;; (* pareil que (incr 2)*2 *)
let y = incr 2 in y*3;;
let bla x =
  if x > 0 then "coucou" else "salut";;
(bla 12)^" wesh";;
let monplus (x:int) (y:int):int = x + y;;
let monplus x y = x + y;;
let concat s x =
  if x >0 then s else "négatif";;

(**W**)
2;;
print_int 2;;
(** fonction qui ne retourne rien*)
let affiche x = print_string x;;
affiche "coucou";;
(*seul cas où un if sans else est autorisé*)
let affiche x =
  if x > 0 then print_int x;;
affiche 12;;
let x =12;;
(*utilisation du simple ; *)
let affiche x =
  (if x > 0 then print_int x);
  (x+1);;
affiche 12;;
let affiche x =
  if x > 0 then (print_int x;x+1)
  else x-1;;
affiche (-3);;

(**le nommage de valeur n'est pas l'affectation de variable *)
let toto = 12;;
let add_toto x = x+toto;;
add_toto 0;;
let toto = 28;;
add_toto 0;;
