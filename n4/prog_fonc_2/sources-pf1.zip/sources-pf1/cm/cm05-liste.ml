[];;

let bonjour = ["coucou"; "salut"];;
let nombre = [1; 2; 3];;

let bonjour = "coucou"::"salut"::[];;
let nombre = 1::2::3::[];;

let cons x l = x :: l;;

let estVIde l =
  match l with
  | [] -> true
  | _::_ -> false;;

let estVide l = (l = []);;

let tete l =
  match l with
  | [] -> failwith "liste vide"
  | t::_ -> t;;


let rec longueur l =
  match l with
  | [] -> 0
  | _::q -> 1 + longueur q;;

let rec supprime l n =
  match l with
  | [] -> []
  | _::q when n = 0 -> q
  | t::q -> t::supprime q (n-1);;

nombre;;
supprime nombre 0;;
supprime nombre 2;;
supprime nombre 3;;

let bla l =
  match l with
  | 1::2::q -> "cas 1"
  | [1] -> "cas 2"
  | 1::[] -> "cas 3"
  | [1; 2] -> "cas 4"
  | _ -> "le reste";;

bla nombre;;
bla [1;2];;
bla [1];;
bla (1::[]);;
bla [];;

(* supprimeImpairs l retourne l sans ses éléments de rang impair *)
let rec supprimeImpairs l =
  match l with
  | [] -> []
  | [t] -> [t]
  | t1::_::q -> t1::(supprimeImpairs q);;

let rec supprimeImpairs l =
  match l with
  | [] -> []
  | t1::_::q -> t1::(supprimeImpairs q);;


supprimeImpairs nombre;;
supprimeImpairs [1; 2; 3; 4; 5];;

let ll = [ [1]; [2; 3]; []];;

let bla2 l =
  match l with
  | [ 1::q] -> "cas 1"
  | [ _ ; [2] ] -> "cas 2"
  | ( _::3::_)::_ -> "cas 3"
  | _ -> "le reste";;


bla2 [ [1; 2; 3] ];;
bla2 [ [1]; [2]; [3] ];;
bla2 [ [1; 3; 2] ];;
bla2 [ [1; 3; 2] ; [] ];;
bla2 [ [12; 3; 2]  ];;


