(* type enregistrement *)
type personne =
  {
    nom : string;
    age : int;
  };;

let lPers = [ {nom = "Toto"; age = 12 } ; {nom = "Marcel"; age = 28} ; {
              nom = "Georgette"; age = 24}  ];;

(* map f l applique la fonction f à chaque élément de l *)
let selectAge p = p.age;;
List.map selectAge lPers;;

(* pour ne pas avoir à préfixer tout le temps *)
open List;;

(* fonction anonyme *)
let lAges = map  (fun x -> x.age) lPers;;

(*remarque : les 2 def suivantes sont équivalentes *)
let selectAge p = p.age;;
let selectAge = fun p -> p.age;;

(* map est une fonction d'ordre supérieur: elle prend en paramètre une *)
(* autre fonction*)
map;;

(* ajoute 1 à chaque élément d'une liste d'entiers *)
map (fun x -> x+1) [1; 2; 3];;
(* passe les caractères en majuscule *)
map (fun c -> Char.uppercase_ascii c) ['a'; 'B'; 'c'];;
(* appliquer un coeff c à une liste de notes *)
map (fun x -> 1.1*.x) [12.; 18.; 8.5];;


(* sélectionne les ages >= 18 *)
let res = filter (fun x -> x >= 18) lAges;;

filter;;


(*sélectionner les entiers positifs d'une liste*)
filter (fun x -> x >0) [12; -1; 23; 0; -2];;
(*sélectionner les occurrences de la lettre 'a' *)
filter (fun c -> c= 'a') ['a'; 'c'; 'a'; 'b'];;

(*on peut enchaîner les opérations*)
let res = filter (fun x -> x >= 18) (map (fun p -> p.age) lPers);;

(*noms des personnes majeures de la liste *)
map (fun p -> p.nom) (filter (fun p -> p.age >= 18) lPers);;
