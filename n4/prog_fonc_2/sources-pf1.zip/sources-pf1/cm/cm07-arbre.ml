type 'a abin =
  | ETree
  | Node of 'a * 'a abin *'a abin;;

let tc = Node('C', ETree, ETree);;
let tabc = Node('A',
                Node('B',ETree,ETree),
                Node('C',ETree,ETree)
             );;
let tbla = Node('B',
                Node('L',
                     Node('A',
                          ETree,
                          ETree),
                     ETree),
                ETree);;

let rec nbf t =
  match t with
  | ETree -> 0
  | Node(_, ETree, ETree) -> 1
  | Node(_, t1, t2) -> (nbf t1) + nbf t2;;

let rec haut t =
  match t with
  | ETree -> 0
  | Node(_, t1, t2) -> (max (haut t1) (haut t2))+1;;
