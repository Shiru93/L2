#include "Fonctions.h"

void trouver_zone_rec_2(int ** M, int dim, int i, int j, int * taille, ListeCase * L, int couleur){
    if(i < 0 || i >= dim || j < 0 || j >= dim) return;

    if(M[i][j] != couleur) return;

    M[i][j] = -1;

    ajoute_en_tete(L, i, j);
    (*taille)++;

    trouver_zone_rec_2(M, dim, i + 1, j, taille, L, couleur);
    trouver_zone_rec_2(M, dim, i - 1, j, taille, L, couleur);
    trouver_zone_rec_2(M, dim, i, j + 1, taille, L, couleur);
    trouver_zone_rec_2(M, dim, i, j - 1, taille, L, couleur);
}

void trouver_zone_rec(int ** M, int dim, int i, int j, int * taille, ListeCase * L){
    int couleur = M[i][j];
    ListeCase courant = *L;
    *taille = 0;

    trouver_zone_rec_2(M, dim, i, j, taille, L, couleur);

    while(courant){
        M[courant->i][courant->j] = couleur;
        courant = courant->suiv;
    }
}

int sequence_aleatoire_rec(int ** M, Grille * G, int dim, int nbcl, int aff){
    int 
        chgmnt_couleurs = 0,
        taille = 0,
        ancienne_couleur,
        nouvelle_couleur;

    ListeCase 
        L = NULL, 
        courant;

    init_liste(&L);

    trouver_zone_rec(M, dim, 0, 0, &taille, &L);

    while(taille < dim * dim){
        chgmnt_couleurs++;

        ancienne_couleur = M[0][0];
        do{
            nouvelle_couleur = rand() % nbcl;
        } while(nouvelle_couleur == ancienne_couleur);

        courant = L;
        while(courant){
            M[courant->i][courant->j] = nouvelle_couleur;
            
            if(aff == 1)
                Grille_attribue_couleur_case(G, courant->i, courant->j, nouvelle_couleur);

            courant = courant->suiv;
        }

        if(aff == 1){
            Grille_redessine_Grille(G);
            Grille_attente_touche();
        }

        detruit_liste(&L);
        init_liste(&L);

        trouver_zone_rec(M, dim, 0, 0, &taille, &L);
    }

    detruit_liste(&L);

    return chgmnt_couleurs;
}