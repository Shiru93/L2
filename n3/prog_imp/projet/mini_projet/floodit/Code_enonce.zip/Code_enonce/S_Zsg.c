#include "S_Zsg.h"

void free_Zsg(S_Zsg * Z){
    detruit_liste(&(Z->Lzsg));
    
    if(Z->B){
        for(int i = 0; i < Z->nbcl; i++){
            detruit_liste(&(Z->B[i]));
        }

        free(Z->B);
    }

    if(Z->App){
        for(int i = 0; i < Z->dim; i++){
            if(Z->App[i]){
                free(Z->App[i]);
            }
        }

        free(Z->App);
    }
}

/* --- Exercice 2.1 --- */
int init_Zsg(S_Zsg * L, int dim, int nbcl){
    L->dim = dim;
    L->nbcl = nbcl;

    init_liste(&(L->Lzsg));

    L->B = malloc(sizeof(ListeCase) * nbcl);
    for(int i = 0; i < nbcl; i++)
        init_liste(&(L->B[i]));

    L->App = malloc(sizeof(int *) * dim);
    if(!L->App)
        return 1;

    for (int i = 0; i < dim; i++){
        L->App[i] = malloc(sizeof(int) * dim);
        for(int j = 0; j < dim; j++)
            L->App[i][j] = -2;
    }

    return 0;
}

void ajoute_Zsg(S_Zsg * L, int i, int j){
    ajoute_en_tete(&(L->Lzsg), i, j);
    L->App[i][j] = -1;
}

void ajoute_Bordure(S_Zsg * L, int i, int j, int nbcl){
    ajoute_en_tete(&(L->B[nbcl]), i, j);
    L->App[i][j] = nbcl;
}

int appartient_Zsg(S_Zsg * L, int i, int j){
    return (L->App[i][j] == -1);
}

int appartient_Bordure(S_Zsg * L, int i, int j, int cl){
    return (L->App[i][j] == cl);
}


/* --- Exercice 2.2 --- */
int agrandit_Zsg(int ** M, S_Zsg * Z, int cl, int k, int l){
    int 
        i, j, 
        nb = 0, 
        x1[] = {0, 0, 1, -1}, 
        y1[] = {1, -1, 0, 0}, 
        x2, y2, 
        nv_couleur;

    ListeCase Pile = NULL;
    
    ajoute_en_tete(&Pile, k, l);


    while(!test_liste_vide(&Pile)){
        enleve_en_tete(&Pile, &i, &j);

        if(Z->App[i][j] == -1)
            continue;

        ajoute_en_tete(&(Z->Lzsg), i, j);
        Z->App[i][j] = -1;

        nb++;

        for(int a = 0; a < 4; a++){
            x2 = i + x1[a];
            y2 = j + y1[a];

            if(x2 >= 0 && x2 < Z->dim && y2 >= 0 && y2 < Z->dim){
                if(Z->App[x2][y2] == -1)
                    continue;

                if(M[x2][y2] == cl){
                    if(Z->App[x2][y2] != -1)
                        ajoute_en_tete(&Pile, x2, y2);
                } else {
                    nv_couleur = M[x2][y2];

                    if(Z->App[x2][y2] != nv_couleur){
                        ajoute_en_tete(&(Z->B[nv_couleur]), x2, y2);
                        Z->App[x2][y2] = nv_couleur;
                    }
                }
            }
        }
    }

    return nb;
}

/* --- Exercice 2.3 --- */
int sequence_aleatoire_rapide(int ** M, Grille * G, int dim, int nbcl, int aff){
    S_Zsg Z;

    int 
        taille = 0,
        chgmt_couleur = 0,
        ancienne_couleur = M[0][0],
        cl;

    ListeCase L, bordure, tmp;

    if(init_Zsg(&Z, dim, nbcl) != 0)
        return -1;

    taille += agrandit_Zsg(M, &Z, ancienne_couleur, 0, 0);

    while(taille < dim * dim){
        chgmt_couleur++;

        do{
            cl = rand() % nbcl;
        } while(cl == ancienne_couleur || test_liste_vide(&(Z.B[cl])));

        ancienne_couleur = cl;

        L = Z.Lzsg;

        while(L){
            M[L->i][L->j] = ancienne_couleur;
            if(aff)
                Grille_attribue_couleur_case(G, L->i, L->j, ancienne_couleur);

            L = L->suiv;
        }

        if(aff)
            Grille_redessine_Grille(G);

        bordure = Z.B[ancienne_couleur];
        Z.B[ancienne_couleur] = NULL;

        while(bordure){
            taille += agrandit_Zsg(M, &Z, ancienne_couleur, bordure->i, bordure->j);
            tmp = bordure;
            bordure = bordure->suiv;
            free(tmp);
        }
    }

    free_Zsg(&Z);

    return chgmt_couleur;
}

/* --- Exercice 3.1 --- */
int nombre_couleur(S_Zsg * Z, int cl){
    int nb = 0;
    ListeCase courant = Z->B[cl];

    while(courant){
        nb++;
        courant = courant->suiv;
    }
    

    return nb;
}

/* --- Exercice 3.2 --- */
int strategie_max_bordure(int ** M, Grille * G, int dim, int nbcl, int aff){
    S_Zsg Z;

    int 
        max_couleur,
        tmp,
        chgmt_couleur = 0,
        taille,
        max_taille = 0,
        ancienne_couleur = M[0][0],
        cl;

    ListeCase
        L,
        bordure,
        tmp_liste;

    if(init_Zsg(&Z, dim, nbcl) != 0)
        return -1;

    taille += agrandit_Zsg(M, &Z, ancienne_couleur, 0, 0);

    while(taille < dim * dim){
        chgmt_couleur++;

        for(int i = 0; i < nbcl; i++){
            if(i == ancienne_couleur)
                continue;

            tmp = nombre_couleur(&Z, i);

            if(tmp > max_taille){
                max_taille = tmp;
                max_couleur = i;
            }
        }

        if(max_couleur == -1)
            continue;

        cl = max_couleur;

        L = Z.Lzsg;
        while(L){
            M[L->i][L->j] = cl;
            if(aff)
                Grille_attribue_couleur_case(G, L->i, L->j, cl);
            L = L->suiv;
        }

        if(aff)
            Grille_redessine_Grille(G);

        bordure = Z.B[cl];
        Z.B[cl] = NULL;

        while(bordure){
            taille += agrandit_Zsg(M, &Z, cl, bordure->i, bordure->j);
            tmp_liste = bordure;
            bordure = bordure->suiv;
            free(tmp_liste);
        }
    }

    free_Zsg(&Z);

    return chgmt_couleur;
}

/* --- Exercice 4.1 --- */
int fonction_annexe(int ** M, int dim, ListeCase bordure, int cl, int ** App){
    int 
        nb_nvl_cases = 0,
        ** visite = malloc(sizeof(int *) * dim),
        i, j,
        x, y,
        xtab[] = {0, 0, 1, -1},
        ytab[] = {1, -1, 0, 0};

    ListeCase 
        Pile = NULL,
        b = bordure;

    for(int k = 0; k < dim; k++)
        visite[k] = calloc(dim, sizeof(int));

    while(b){
        ajoute_en_tete(&Pile, b->i, b->j);
        b = b->suiv;
    }

    while(!test_liste_vide(&Pile)){
        enleve_en_tete(&Pile, &i, &j);

        if(visite[i][j] == 1 || App[i][j] == -1)
            continue;
        
        visite[i][j] = 1;
        nb_nvl_cases++;

        for(int v = 0; v < 4; v++){
            x = i + xtab[v];
            y = j + ytab[v];

            if(x >= 0 && x < dim && y >= 0 && y < dim){
                if(M[x][y] == cl && App[x][y] != -1 && visite[x][y] == 0){
                    ajoute_en_tete(&Pile, x, y);
                }
            }
        }
    }

    for(int i = 0; i < dim; i++)
        free(visite[i]);

    free(visite);

    return nb_nvl_cases;
}

int strategie_max_bordure_zone(int ** M, Grille * G, int dim, int nbcl, int aff){
    S_Zsg Z;

    int 
        taille = 0,
        chgmt_couleur = 0,
        ancienne_couleur = M[0][0],
        max_couleur,
        max_gain,
        simule_gain;

    ListeCase 
        L,
        bordure,
        tmp;

    if(init_Zsg(&Z, dim, nbcl) != 0)
        return -1;

    taille += agrandit_Zsg(M, &Z, ancienne_couleur, 0, 0);

    while(taille < dim * dim){
        chgmt_couleur++;

        max_couleur = -1;
        max_gain = -1;

        for(int c = 0; c < nbcl; c++){
            if(c == ancienne_couleur)
                continue;

            if(test_liste_vide(&(Z.B[c])))
                continue;

            simule_gain = fonction_annexe(M, dim, Z.B[c], c, Z.App);

            if(simule_gain > max_gain){
                max_gain = simule_gain;
                max_couleur = c;
            }
        }

        if(max_couleur == -1)
            break;

        ancienne_couleur = max_couleur;

        L = Z.Lzsg;
        while(L){
            M[L->i][L->j]= ancienne_couleur;
            if(aff) Grille_attribue_couleur_case(G, L->i, L->j, ancienne_couleur);
            L = L->suiv;
        }

        if(aff)
            Grille_redessine_Grille(G);

        bordure = Z.B[ancienne_couleur];
        Z.B[ancienne_couleur] = NULL;

        while(bordure){
            taille += agrandit_Zsg(M, &Z, ancienne_couleur, bordure->i, bordure->j);
            tmp = bordure;
            bordure = bordure->suiv;
            free(tmp);
        }
    }

    free_Zsg(&Z);

    return chgmt_couleur;
}